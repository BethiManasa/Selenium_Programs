package Utilities;

import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWriter {
	 public static void main(String[] args) {
	        // Create a Workbook
	        Workbook workbook = new XSSFWorkbook();

	        // Create a Sheet
	        Sheet sheet = workbook.createSheet("Data");

	        // Data to write into Excel
	        Object[][] data = {
	                {"Name", "Age", "Country"},
	                {"John", 30, "USA"},
	                {"Alice", 25, "UK"},
	                {"Bob", 35, "Canada"}
	        };

	        // Write data to the sheet
	        int rowNum = 0;
	        for (Object[] rowData : data) {
	            Row row = sheet.createRow(rowNum++);
	            int colNum = 0;
	            for (Object field : rowData) {
	                Cell cell = row.createCell(colNum++);
	                if (field instanceof String) {
	                    cell.setCellValue((String) field);
	                } else if (field instanceof Integer) {
	                    cell.setCellValue((Integer) field);
	                }
	            }
	        }
	       
	        // Write the output to a file
	    try (FileOutputStream fileOut = new FileOutputStream("C:\\Users\\BEMANASA\\eclipse-workspace\\Toll\\src\\test\\resources\\Excel\\\\DataWriter.xlsx")) {
	            workbook.write(fileOut);
	            System.out.println("Excel file has been generated successfully!");
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                workbook.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }

}
