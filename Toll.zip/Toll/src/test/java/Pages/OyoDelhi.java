package Pages;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OyoDelhi extends GenericMethods {
	WebDriver driver;

	public OyoDelhi(WebDriver driver) {
		this.driver = driver;
	}

	By Delhi = By.xpath("(//div[@class='mddCityItem__cityData'])[3]");
	By Date = By.xpath("(//div[@class='oyo-cell headerSticky__rightHeader']//child::div)[9]");
	By date3 = By.xpath("(//span[text()='3'])[3]");
	By date4 = By.xpath("(//span[text()='4'])[2]");
	By rooms = By.xpath("(//div[@class='oyo-cell headerSticky__rightHeader']//child::div)[10]");
	By Plusicon = By.xpath("//span[@class='guestRoomPickerPopUp__plus']");
	By Search = By.xpath("//button[text()='Search']");
	By Mahipalpur = By.xpath("//div[@class='TileGroupWrapper']//child::div[1]");
	By Collections = By.xpath("//div[text()='Family OYOs']");
	By Categories = By.xpath("//span[text()='OYOX Design']");
	By Accomodation = By.xpath("//div[text()='OYO Home']");
	By Facilities = By.xpath("(//div[@class='checkBoxGroup'])[position()=4]//child::label");
   By Kitchen = By.xpath("//div[text()='Kitchen']");
   By Geyser = By.xpath("//div[text()='Geyser']");
   By Freewifi = By.xpath("//div[text()='Free Wifi']");
   By Elevator = By.xpath("//div[text()='Elevator']");
	By Payment = By.xpath("//div[text()='Pay at Hotel']");
	By Hotel = By.xpath("//a[@class='c-nn640c u-width100']/h3");
	By Photos = By.xpath("//div[text()='View all photos']");
	By Cancel = By.xpath("//div[text()='×']");
	

	public void Selecting_Oyorooms_Delhi() {
		WebElement delhi = driver.findElement(Delhi);
		waits(driver, Duration.ofSeconds(20), Delhi);
		Click(delhi);
		log.debug("Clicked on Delhi");
		WebElement date = driver.findElement(Date);
		waits(driver, Duration.ofSeconds(10), Date);
		Click(date);
		log.debug("Clicked on Select date");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement select3 = driver.findElement(date3);
		waits(driver, Duration.ofSeconds(20), date3);
		Click(select3);
		log.debug("Selected the indate as March 3");
		WebElement select4 = driver.findElement(date4);
		waits(driver, Duration.ofSeconds(20), date4);
		Click(select4);
		log.debug("Selected the outdate as March 4");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement room = driver.findElement(rooms);
		waits(driver, Duration.ofSeconds(20), rooms);
		Click(room);
		log.debug("Clicked on Rooms");
		WebElement plus = driver.findElement(Plusicon);
		for (int i = 0; i < 3; i++) {
			plus.click();
		}
		log.debug("Selected 1 room with 3 Guests");
		WebElement search = driver.findElement(Search);
		waits(driver, Duration.ofSeconds(20), Search);
		Click(search);
		log.debug("Clicked on Search");
		WebElement mahipalpur = driver.findElement(Mahipalpur);
		waits(driver, Duration.ofSeconds(20), Mahipalpur);
		Click(mahipalpur);
		log.debug("Selected the Location Mahipalpur in Delhi");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		WebElement collection = driver.findElement(Collections);
		waits(driver, Duration.ofSeconds(10), Collections);
		executor.executeScript("arguments[0].click();", collection);
		log.debug("Clicked on Family Oyo in Collection");
		WebElement category = driver.findElement(Categories);
		waits(driver, Duration.ofSeconds(20), Categories);
		executor.executeScript("arguments[0].click();", category);
		log.debug("Clicked on OYOX Design in Categories");
		WebElement accomodation = driver.findElement(Accomodation);
		waits(driver, Duration.ofSeconds(20), Accomodation);
		executor.executeScript("arguments[0].click();", accomodation);
		log.debug("Clicked Oyo house as Accomodation type ");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement kitchen = driver.findElement(Kitchen);
		waits(driver, Duration.ofSeconds(10), Kitchen);
		executor.executeScript("arguments[0].click();", kitchen);
		log.debug("Clicked kitchen in Home Facilities ");
		WebElement geyser = driver.findElement(Geyser);
		waits(driver, Duration.ofSeconds(10), Geyser);
		executor.executeScript("arguments[0].click();", geyser);
		log.debug("Clicked Geyser in Home Facilities ");
		WebElement wifi = driver.findElement(Freewifi);
		waits(driver, Duration.ofSeconds(20), Freewifi);
		executor.executeScript("arguments[0].click();",wifi );
		log.debug("Clicked Free wifi in Home Facilities ");
		WebElement elevator = driver.findElement(Elevator);
		waits(driver, Duration.ofSeconds(20), Elevator);
		executor.executeScript("arguments[0].click();", elevator);
		log.debug("Clicked Elevator in Home Facilities ");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement pay = driver.findElement(Payment);
		waits(driver, Duration.ofSeconds(10), Payment);
		executor.executeScript("arguments[0].click();", pay);
		log.debug("Clicked Pay at hotel in Checkin feature");
		WebElement hotel = driver.findElement(Hotel);
		waits(driver, Duration.ofSeconds(20), Hotel);
		executor.executeScript("arguments[0].click();", hotel);
		log.debug("Selected 79600 The Premium Villa");
		String parent_win = driver.getWindowHandle();
		Set<String> set = driver.getWindowHandles();
		Iterator<String> I = set.iterator();
		while (I.hasNext()) {
			String child_win = I.next();
			if (!(parent_win.equals(child_win))) {
				driver.switchTo().window(child_win);
			}
		}
		
		WebElement photos = driver.findElement(Photos);
		waits(driver, Duration.ofSeconds(20), Photos);
		Click(photos);
		log.debug("Clicked on View all photos");
		WebElement cancel = driver.findElement(Cancel);
		waits(driver, Duration.ofSeconds(20), Cancel);
		Click(cancel);
		log.debug("Clicked on Cancel option");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("window.scrollBy(0,1000)");
		log.debug("Scroll down");
		
	}
}
