package Pages;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class Painting_Cleaning extends GenericMethods {
	WebDriver driver;
	public Painting_Cleaning(WebDriver driver) {
		this.driver = driver;
	}
	By Login = By.xpath("(//div[@class='m-auto py-0.8p'])[2]//div");
	By MobileNo = By.xpath("//input[@id='signUp-phoneNumber']");
	By radio = By.xpath("(//input[@name='loginType'])[2]");
	By Password = By.id("login-signup-form__password-input");
    By Continue = By.xpath("//button[@id='signUpSubmit']");
    By Menu = By.xpath("//div[@id='main-menu']/div[1]/img");
    By PaintingCleaning = By.xpath("//div[@style='box-shadow:0 10px 10px 0 rgba(0, 0, 0, 0.1);max-height:calc(100vh - 52px)']/a[3]");
  //  By Select = By.xpath("//*[@id=\"app\"]/div/div/div/div/div[2]/div/header/nav/div[2]/div[1]/button/span[2]");
    By City = By.xpath("//div[@id='modal-root']/div/div[2]/div/div[2]/div/div[1]/div");
    By Painting = By.xpath("((//div[@id='hs_painting'])[1]//child::div)[4]");
    By Interiorpainting = By.xpath("(//div[text()='Interior Painting'])[1]");
    By GetEstimate1 = By.xpath("(//button[text()='GET ESTIMATE'])[2]");
    By Exteriorpainting = By.xpath("(//div[text()='Exterior Painting'])[1]");
    By GetEstimate2 = By.xpath("(//button[text()='GET ESTIMATE'])[3]");
    By WaterProofing = By.xpath("//div[text()='Water Proofing']");
    By GetEstimate3 = By.xpath("(//button[text()='GET ESTIMATE'])[4]");
    By OnewallPainting = By.xpath("//div[text()='One wall Painting']");
    By Text = By.xpath("//div[@id='ONE_WALL_PAINTING']/div[1]");
    By HomeCleaning = By.xpath("//div[text()='Home Cleaning']");
    By FullhouseCleaning = By.xpath("(//div[text()='Full House Cleaning'])[2]");
    By Text1 = By.xpath("//div[@class='px-6 pt-5 pb-6 bg-center bg-cover md:pb-0 ']/h1");
    By KitchenCleaning = By.xpath("(//div[text()='Kitchen Cleaning'])[2]");
    By Text2 = By.xpath("//div[@class='px-6 pt-5 pb-6 bg-center bg-cover md:pb-0 ']/h1");
    By Sofacleaning = By.xpath("(//div[text()='Sofa Cleaning'])[2]");
    By Text3 = By.xpath("//div[@class='px-6 pt-5 pb-6 bg-center bg-cover md:pb-0 ']/h1");
    public void NoBroker_Login() {
    	WebElement logn = driver.findElement(Login);
    	waits(driver, Duration.ofSeconds(20), Login);
    	Click(logn);
    	log.debug("Clicked on Login");
    	WebElement mobile = driver.findElement(MobileNo);
    	waits(driver, Duration.ofSeconds(20), MobileNo);
    	Sendkeys(mobile, "9030378300");
    	log.debug("Entered Mobile Number");
    	WebElement Radio = driver.findElement(radio);
    	waits(driver, Duration.ofSeconds(20), radio);
    	Click(Radio);
    	log.debug("Clicked on I have Password");
    	WebElement password = driver.findElement(Password);
    	waits(driver, Duration.ofSeconds(20), Password);
    	Sendkeys(password, "Manasa@1159");
    	log.debug("Entered Password");
    	try {
			takescreenshot("NoBroker_Login");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	WebElement contnue = driver.findElement(Continue);
    	waits(driver, Duration.ofSeconds(20), Continue);
    	Click(contnue);
    	log.debug("Clicked on Continue");
    	log.debug("Captured Screenshot Successfully");
    }
    public void Painting_Cleaning_Facilities() {
    	WebElement element = driver.findElement(Menu);
    	waits(driver, Duration.ofSeconds(30), Menu);
    	JavascriptExecutor executor = (JavascriptExecutor)driver;
    	executor.executeScript("arguments[0].click();", element);
    	log.debug("Clicked on Menu");
    	WebElement paintingclean = driver.findElement(PaintingCleaning);
    	waits(driver, Duration.ofSeconds(10), PaintingCleaning);
    	executor.executeScript("arguments[0].click();", paintingclean);
    	log.debug("Clicked on Painting& Cleaning");
//    	WebElement sel = driver.findElement(Select);
//    	waits(driver, Duration.ofSeconds(20), Select);
//    	Click(sel);
    	WebElement ct = driver.findElement(City);
    	waits(driver, Duration.ofSeconds(10), City);
    	Click(ct);
    	log.debug("Selected the City as Bangalore");
    	WebElement paint1 = driver.findElement(Painting);
    	waits(driver, Duration.ofSeconds(20), Painting);
    	Click(paint1);
    	log.debug("Clicked on Painting");
    	WebElement interior = driver.findElement(Interiorpainting);
    	waits(driver, Duration.ofSeconds(20), Interiorpainting);
    	Click(interior);
    	log.debug("Clicked on Interior Painting");
    	WebElement getestimate1 = driver.findElement(GetEstimate1);
    	waits(driver, Duration.ofSeconds(20), GetEstimate1);
    	executor.executeScript("arguments[0].click();", getestimate1);
    	log.debug("Clicked on GetEstimate");
    	driver.navigate().to("https://www.nobroker.in/painting-services-in-bangalore");
    	WebElement Exterior = driver.findElement(Exteriorpainting);
    	waits(driver, Duration.ofSeconds(20), Exteriorpainting);
    	Click(Exterior);
    	log.debug("Clicked on Exterior Painting");
    	WebElement getestimate2 = driver.findElement(GetEstimate2);
    	waits(driver, Duration.ofSeconds(20), GetEstimate2);
    	executor.executeScript("arguments[0].click();", getestimate2);
    	log.debug("Clicked on GetEstimate");
    	driver.navigate().to("https://www.nobroker.in/painting-services-in-bangalore");
    	WebElement waterproof = driver.findElement(WaterProofing);
    	waits(driver, Duration.ofSeconds(20), WaterProofing);
    	Click(waterproof);
    	log.debug("Clicked on Waterproof Cleaning");
    	WebElement getestimate3 = driver.findElement(GetEstimate3);
    	waits(driver, Duration.ofSeconds(20), GetEstimate3);
    	executor.executeScript("arguments[0].click();", getestimate3);
    	log.debug("Clicked on GetEstimate");
    	driver.navigate().to("https://www.nobroker.in/home-services-in-bangalore?nbFr=Home_page");
    	WebElement wallpaint = driver.findElement(OnewallPainting);
    	waits(driver, Duration.ofSeconds(20), OnewallPainting);
    	Click(wallpaint);
    	log.debug("Clicked on One wallPainting");
    	WebElement text = driver.findElement(Text);
    	waits(driver, Duration.ofSeconds(20), Text);
    	String txt = getText(text);
    	System.out.println("The text after Clicking on Wallpainting is :"+txt);
    	driver.navigate().back();
    	WebElement homecleaning = driver.findElement(HomeCleaning);
    	waits(driver, Duration.ofSeconds(20), HomeCleaning);
    	Click(homecleaning);
    	log.debug("Clicked on HomeCleaning");
    	//https://www.nobroker.in/home-services-in-bangalore?nbFr=Home_page
    	WebElement fullhouse = driver.findElement(FullhouseCleaning);
    	waits(driver, Duration.ofSeconds(20), FullhouseCleaning);
    	Click(fullhouse);
    	log.debug("Clicked on FullHouse");
    	WebElement text1 = driver.findElement(Text1);
    	waits(driver, Duration.ofSeconds(20), Text1);
    	String a = getText(text1);
    	System.out.println("The text after Selecting Full house:"+a);
    	driver.navigate().back();
    	WebElement homecleaning1 = driver.findElement(HomeCleaning);
    	waits(driver, Duration.ofSeconds(20), HomeCleaning);
    	Click(homecleaning1);
    	log.debug("Clicked on HomeCleaning");
    	WebElement kitchenclean = driver.findElement(KitchenCleaning);
    	waits(driver, Duration.ofSeconds(20), KitchenCleaning);
    	Click(kitchenclean);
    	log.debug("Clicked on Kitchen Cleaning");
    	WebElement text2 = driver.findElement(Text2);
    	waits(driver, Duration.ofSeconds(20), Text2);
    	String b= getText(text2);
    	System.out.println("The text after Selecting Kitchen Cleaning:"+b);
    	driver.navigate().back();
    	WebElement homecleaning2 = driver.findElement(HomeCleaning);
    	waits(driver, Duration.ofSeconds(20), HomeCleaning);
    	Click(homecleaning2);
    	log.debug("Clicked on HomeCleaning");
    	WebElement sofa = driver.findElement(Sofacleaning);
    	waits(driver, Duration.ofSeconds(20), Sofacleaning);
    	Click(sofa);
    	log.debug("Clicked on SofaCleaning");
    	WebElement text3 = driver.findElement(Text3);
    	waits(driver, Duration.ofSeconds(10), Text3);
        String c = getText(text3);
        System.out.println("The text after Selecting Sofa Cleaning:"+c);
         

    	
    }
    
}
