package Pages;

import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Shoppre extends GenericMethods{
	WebDriver driver;
	public Shoppre(WebDriver driver) {
		this.driver = driver;
	}
	By signup = By.xpath("//li[@id='show_signup']/a");
	By Firstname = By.xpath("//div[@class='col-md-6 col-xs-12 no-pad-right']//child::div[2]/input");
	By Lastname = By.xpath("(//div[@class='col-md-6 col-xs-12']//following-sibling::div)[1]//input");
	By email = By.xpath("(//div[@class='list-group-item'])[3]/input");
	By password = By.xpath("(//div[@class='list-group-item'])[4]//input");
	By SignUp = By.xpath("//button[text()='Sign Up']");
	By Shipments = By.xpath("//div[@id='app']/div[1]/div/div/nav/ul/li[5]/a/span[2]");
	By History = By.xpath("//span[text()='History']");
	By Text = By.xpath("//div[@id=\"app\"]/div[2]/div[2]/div[2]/div/div/div/div/div[2]/div/div/div[1]/div/div/div/div/div/div/h3/p");
	By IndianStores = By.xpath("//div[@id='app']/div[1]/div/div/nav/ul/li[9]/a/span");
	By ekatva = By.xpath("(//div[@class='br-box3'])[4]");
	By Keralasaree = By.xpath("/html/body/div[3]/div[4]/div/div/div[1]/div/div/section[4]/div/div/div[1]/div/div/div/div/div/div/h5/a");
	//By DropDown = By.xpath("//div[@role='listbox']") ;
    By Cotton = By.xpath("//input[@value='TissueCotton']");
    By Selectsaree = By.xpath("//div[@id='scroll0']/a/div[2]/p");
    By AddBag = By.xpath("//div[@id='app']/div[1]/main/div/div[1]/div[1]/div[2]/div[2]/button/span/span");
    By Checkout = By.xpath("(//button[@type='button'])[12]//span");
    By Securecheck = By.xpath("//div[@id='app']/div[2]/main/div/div/div/div[1]/div[2]/div/button/span");
	public void SignUp(String FirstName,String LastName,String Email,String Password) {
	  WebElement sign = driver.findElement(signup);
	  Click(sign);
	  log.debug("Clicked on SignUp");
	  String parent_win = driver.getWindowHandle();     
		Set<String> set = driver.getWindowHandles();     
		Iterator<String> I = set.iterator();
	   while(I.hasNext()){
		   String child_win =I.next();
		   if(!(parent_win.equals(child_win))) {
			   driver.switchTo().window(child_win);
		   }
		}
	  WebElement a = driver.findElement(Firstname);
	  waits(driver, Duration.ofSeconds(10), Firstname);
	  Sendkeys(a, FirstName);
	  log.debug("Enter the FirstName Successfully");
	  WebElement b = driver.findElement(Lastname);
	  waits(driver, Duration.ofSeconds(10), Firstname);
	  Sendkeys(b, LastName);
	  log.debug("Enter the LastName Successfully");
	   WebElement c = driver.findElement(email);
	   waits(driver, Duration.ofSeconds(10), Firstname);
	   Sendkeys(c, Email);
	   log.debug("Enter an Email Successfully");
	   WebElement d = driver.findElement(password);
	   waits(driver, Duration.ofSeconds(10), Firstname);
	   Sendkeys(d, Password);
	   log.debug("Enter the Password Successfully");
	   try {
		takescreenshot("Shoppre_SignUp");
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	   WebElement e = driver.findElement(SignUp);
       Click(e);
       log.debug("Clicked on Signup");
       
   }
  public void Stores() {
      WebElement ship = driver.findElement(Shipments);
      waits(driver, Duration.ofSeconds(10), Shipments);
      Click(ship);
      log.debug("Clicked on Shipments");
      WebElement history = driver.findElement(History);
      waits(driver, Duration.ofSeconds(10), History);
      Click(history);
      log.debug("Clicked on History");
      log.debug("The text Displayed is:'You have No Shipments Currently'");
      try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  WebElement stores = driver.findElement(IndianStores);
      waits(driver, Duration.ofSeconds(20), IndianStores);
      Click(stores);
      log.debug("Clicked on Stores");
	  WebElement ekat = driver.findElement(ekatva);
	  waits(driver, Duration.ofSeconds(10), ekatva);
	  Click(ekat);
	  log.debug("Clicked on Ekatva");
	  String parent_win = driver.getWindowHandle();     
		Set<String> set = driver.getWindowHandles();     
		Iterator<String> I = set.iterator();
	   while(I.hasNext()){
		   String child_win =I.next();
		   if(!(parent_win.equals(child_win))) {
			   driver.switchTo().window(child_win);
		   }
		}
	  JavascriptExecutor js = (JavascriptExecutor)driver;
	  js.executeScript("window.scrollBy(0,700)");
	  WebElement saree = driver.findElement(Keralasaree);
	  waits(driver, Duration.ofSeconds(40), Keralasaree);
	  Click(saree);
	  log.debug("Clicked on Kerala Sarees");
	  String parent_win1 = driver.getWindowHandle();     
		Set<String> set1 = driver.getWindowHandles();     
		Iterator<String> I1 = set1.iterator();
	   while(I1.hasNext()){
		   String child_win1 =I1.next();
		   if(!(parent_win1.equals(child_win1))) {
			   driver.switchTo().window(child_win1);
		   }
		} 
	  WebElement se = driver.findElement(Selectsaree);
	  waits(driver, Duration.ofSeconds(40), Selectsaree);
	  Click(se);
	  log.debug("Kerala Kasavu Saree With Warli Hand Block Prints is selected");
	  WebElement add = driver.findElement(AddBag);
	  waits(driver, Duration.ofSeconds(40), AddBag);
	  Click(add);
	  log.debug("Product added to the Cart");
	  WebElement check = driver.findElement(Checkout);
	  waits(driver, Duration.ofSeconds(40), Checkout);
	  Click(check);
	  log.debug("Successfully clicked on Checkout");
	  WebElement secure = driver.findElement(Securecheck);
	  waits(driver, Duration.ofSeconds(40), Securecheck);
	  Click(secure);
	  log.debug("Clicked on Secure Checkout");
	  log.debug("The Payment page is Displayed");
		 
	  
  }
}
