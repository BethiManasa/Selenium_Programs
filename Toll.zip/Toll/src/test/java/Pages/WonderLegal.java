package Pages;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
public class WonderLegal extends GenericMethods {
	public static WebDriver driver;
	public WonderLegal(WebDriver driver) {
		this.driver = driver;	
	}
	By documents = By.xpath("//li[@class='documents_lien_menu dropdown']/a");
    By personal = By.xpath("//div[@id='menu']/nav/ul/li[2]/ul/li[2]/a");
	By Letterrequesting = By.xpath("//a[text()='Letter Requesting Leave']");
	By FillTemplate = By.xpath("//html//body//div[1]//div[2]//div[2]//div[1]/a");
	By Name = By.xpath("//input[@id='employee_name']");
	By Next1 = By.xpath("//button[@name='suivant']");
	By Email = By.xpath("//input[@name='email_address']");
	By Next2 = By.xpath("//button[@name='suivant']");
	By Date = By.xpath("//input[@placeholder='dd-mm-yyyy']");
	By Select = By.xpath("//a[@data-date='29']");
	By Employer = By.xpath("//input[@id='company_name']");
	By Next3 = By.xpath("//button[@name='suivant']");
	By Address = By.xpath("//textarea[@id='company_address']");
	By Next4 = By.xpath("//button[@name='suivant']");
	By Letterto = By.xpath("//input[@name='concerned_person']");
	By Next5 = By.xpath("//button[@name='suivant']");
	By Discussion = By.xpath("//input[@name='when_discussed']");
	By Date1 = By.xpath("//a[@data-date='29']");
	By Requestingleave = By.xpath("//input[@name='start_date']");
	By Date2 = By.xpath("//a[@data-date='30']");
	By EndDate = By.xpath("//input[@name='end_date']");
	By April = By.xpath("//select[@aria-label='Select month']");
	By Date3 = By.xpath("//a[@data-date='29']");
	By Next6 = By.xpath("//button[@name='suivant']");
	By LeaveDuration = By.xpath("//input[@name='xdays']");
	By Returndate = By.xpath("//input[@name='return_date']");
	By Month = By.xpath("//select[@aria-label='Select month']");
	By Date4 = By.xpath("//a[@data-date='25']");
	By Next7 = By.xpath("//button[@name='suivant']");
	By Next8 = By.xpath("//button[@name='suivant']");
	By Reason = By.xpath("//textarea[@name='special_condition']");
	By Next9 = By.xpath("//button[@name='suivant']");
	By Next10 = By.xpath("//button[@name='suivant']");
	By Colleague = By.xpath("//input[@name='colleague_name']");
	By Next11 = By.xpath("//button[@name='suivant']");
	By Next12 = By.xpath("//button[@name='suivant']");
	By Finish = By.xpath("//button[@name='suivant']");
	public void LeaveRequestLetter() {
		WebElement doc = driver.findElement(documents);
		waits(driver, Duration.ofSeconds(10), documents);
		Actions act = new Actions(driver);
		act.moveToElement(doc).perform();
		log.debug("Moved to Element Documnet");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement persnal = driver.findElement(personal);
		waits(driver, Duration.ofSeconds(10), personal);
		Click(persnal);
		log.debug("Clicked on Personal");
		WebElement leave = driver.findElement(Letterrequesting);
		waits(driver, Duration.ofSeconds(10), Letterrequesting);
		Click(leave);
		log.debug("Navigated to templates documents and Clicked on Leave Requesting letter");
		WebElement template = driver.findElement(FillTemplate);
		waits(driver, Duration.ofSeconds(10), FillTemplate);
		Click(template);
		log.debug("Clicked on Fill out the template");
		WebElement name = driver.findElement(Name);
		waits(driver, Duration.ofSeconds(10), Name);
		Sendkeys(name, "Harshitha");
		log.debug("Entered the name of the Employee");
		WebElement next = driver.findElement(Next1);
		waits(driver, Duration.ofSeconds(10), Next1);
		Click(next);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement email = driver.findElement(Email);
		waits(driver, Duration.ofSeconds(10), Email);
		Sendkeys(email, "abc.123@gmail.com");
		log.debug("Entered Email of an Employe");
		WebElement next1 = driver.findElement(Next2);
		waits(driver, Duration.ofSeconds(10), Next2);
		Click(next1);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement date = driver.findElement(Date);
		waits(driver, Duration.ofSeconds(10), Date);
		Click(date);
		log.debug("Clicked on Letter to Send");
		WebElement select = driver.findElement(Select);
		waits(driver, Duration.ofSeconds(10), Select);
		Click(select);
		log.debug("Selected the date as 29/03/2024");
		WebElement employer = driver.findElement(Employer);
		waits(driver, Duration.ofSeconds(10), Employer);
		Sendkeys(employer, "Sravani");
		log.debug("Entered to whom the lettered is sending");
		WebElement next2 = driver.findElement(Next3);
		waits(driver, Duration.ofSeconds(10), Next3);
		Click(next2);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement address = driver.findElement(Address);
		waits(driver, Duration.ofSeconds(10), Address);
		Sendkeys(address, "BEML,ITPL Main Road,560066");
		log.debug("Entered the address of an Employe");
		WebElement next3 = driver.findElement(Next4);
		waits(driver, Duration.ofSeconds(10), Next4);
		Click(next3);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement letterto = driver.findElement(Letterto);
		waits(driver, Duration.ofSeconds(10),Letterto );
		Sendkeys(letterto, "Raju Bairi");
		log.debug("Entered the name of Concerned person");
		WebElement next4 = driver.findElement(Next5);
		waits(driver, Duration.ofSeconds(10), Next5);
		Click(next4);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement discussion = driver.findElement(Discussion);
		waits(driver, Duration.ofSeconds(10), Discussion);
		Click(discussion);
		log.debug("Clicked on Discussion date");
		WebElement date1 = driver.findElement(Date1);
		waits(driver, Duration.ofSeconds(10), Date1);
		Click(date1);
		log.debug("Selected the Discussion date as 29/03/2024");
		WebElement requestingleave = driver.findElement(Requestingleave);
		waits(driver, Duration.ofSeconds(10), Requestingleave);
		Click(requestingleave);
		log.debug("Clicked on requesting leave");
		WebElement date2 = driver.findElement(Date2);
		waits(driver, Duration.ofSeconds(10), Date2);
		Click(date2);
		log.debug("Selected requesting leave date as 30/03/2024");
		WebElement endadte = driver.findElement(EndDate);
		waits(driver, Duration.ofSeconds(10), EndDate);
		Click(endadte);
		log.debug("Clicked on End date of leave");
		WebElement april = driver.findElement(April);
		waits(driver, Duration.ofSeconds(10), April);
		Dropdown(april, "April");
		log.debug("Selected the month as April");
		WebElement date3 = driver.findElement(Date3);
		waits(driver, Duration.ofSeconds(10), Date3);
		Click(date3);
		log.debug("Selected the date as 25/4/2024");
		WebElement next5 = driver.findElement(Next6);
		waits(driver, Duration.ofSeconds(10), Next6);
		Click(next5);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement duration = driver.findElement(LeaveDuration);
		waits(driver, Duration.ofSeconds(10), LeaveDuration);
		Sendkeys(duration, "20");
		log.debug("Entered duration of leave is 20 days ");
		WebElement returndate = driver.findElement(Returndate);
		waits(driver, Duration.ofSeconds(10), Returndate);
		Click(returndate);
		log.debug("Clicked on return date from leave");
		WebElement month = driver.findElement(Month);
		waits(driver, Duration.ofSeconds(10), Month);
		Dropdown(month, "April");
		log.debug("Selected the Month as April");
		WebElement date4= driver.findElement(Date4);
		waits(driver, Duration.ofSeconds(10), Date4);
		Click(date4);
		log.debug("Selected date is 25/04/2024");
		WebElement next6 = driver.findElement(Next7);
		waits(driver, Duration.ofSeconds(10), Next7);
		Click(next6);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement next7 = driver.findElement(Next8);
		waits(driver, Duration.ofSeconds(10), Next8);
		Click(next7);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement reason = driver.findElement(Reason);
		waits(driver, Duration.ofSeconds(10), Reason);
		Sendkeys(reason, "Vacation");
		log.debug("Entered The Reason for Leave is Vacation");
		WebElement next8 = driver.findElement(Next9);
		waits(driver, Duration.ofSeconds(10), Next9);
		Click(next8);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement next9 = driver.findElement(Next10);
		waits(driver, Duration.ofSeconds(10), Next10);
		Click(next9);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement colleague = driver.findElement(Colleague);
		waits(driver, Duration.ofSeconds(10), Colleague);
		Sendkeys(colleague, "Manasa");
		log.debug("Entered the Name of colleague who will be handling the workload");
		WebElement next10 = driver.findElement(Next11);
		waits(driver, Duration.ofSeconds(10), Next11);
		Click(next10);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement next11 = driver.findElement(Next12);
		waits(driver, Duration.ofSeconds(10), Next12);
		Click(next11);	
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement finish = driver.findElement(Finish);
		waits(driver, Duration.ofSeconds(10), Finish);
		Click(finish);
		log.debug("Clicked on Finish");
		try {
			takescreenshot("worldlegal_Doc");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
}
