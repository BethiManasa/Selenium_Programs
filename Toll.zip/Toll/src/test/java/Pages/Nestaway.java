package Pages;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class Nestaway extends GenericMethods {
	WebDriver driver;
	public Nestaway(WebDriver driver) {
		this.driver= driver;
	}
	By Menu = By.xpath("//div[@class='flex cursor-pointer flex-col items-center gap-y-1 duration-500  hover:opacity-50']");
    By Loginbefore = By.xpath("//button[text()='Login']");
    By email = By.xpath("//input[@placeholder='Email id/ Phone number']");
    By Continue= By.xpath("//input[@placeholder='Email id/ Phone number']//following::div[1]/button");
    By password = By.xpath("//input[@placeholder='Enter Password']");
    By LoginAftr= By.xpath("//input[@placeholder='Enter Password']//following::div[1]//button");
    By Explore = By.xpath("/html/body/header/div/div/div[2]/div[1]/div[2]/div[3]/ul/li[1]/a");
	By Independenthouse = By.xpath("//button[text()='Independent House']");
	By Search = By.xpath("//input[@placeholder='Search Locality ']");
	By Propertytype = By.xpath("//span[text()='Property Type']");
	By House = By.xpath("//li[text()='Independent House']");
	By Lookingfor = By.xpath("//span[text()='Looking For']");
	By EntireHouse = By.xpath("//li[text()='Entire House']");
	By Tenanttype = By.xpath("//span[text()='Tenant Type']");
	By Family = By.xpath("//li[text()='Family']");
	By Sort = By.xpath("(//span[text()='Sort'])[1]");
	By Price = By.xpath("(//li[text()='Price: Low to High'])[1]");
	By Filters = By.xpath("(//div[@class='ml-2 h-5 w-5 '])[2]");
	By Bhk = By.xpath("(//div[text()='2 BHK'])[1]");
	By Applyfilters = By.xpath("//button[text()='Apply Filters']");
	By Text = By.xpath("(//p[text()='Semi furnished 2 BHK in  silver spring layout, munekolala'])[1]");
	By Cancel = By.xpath("//div[@class='ml-2 h-5 w-5 !w-4 !ml-0 h-2 text-neutral-silver  p-0']");
	
	
	public void Nestaway_Login(String Email,String Password) {
		WebElement menu = driver.findElement(Menu);
		waits(driver, Duration.ofSeconds(10), Menu);
		Click(menu);
		log.debug("Clicked on Menu");
		WebElement login = driver.findElement(Loginbefore);
		waits(driver, Duration.ofSeconds(10), Loginbefore);
		Click(login);
		log.debug("Clicked on Login");
		WebElement mail = driver.findElement(email);
		waits(driver, Duration.ofSeconds(10), email);
		Sendkeys(mail, Email);
		log.debug("Entered Email Successfully");
		WebElement contnue = driver.findElement(Continue);
		waits(driver, Duration.ofSeconds(10), Continue);
		Click(contnue);
		log.debug("Clicked on Continue");
		WebElement pswd = driver.findElement(password);
		waits(driver, Duration.ofSeconds(10), password);
		Sendkeys(pswd,Password );
		log.debug("Entered Password Successfully");
		try {
			takescreenshot("Nestaway_Login");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		log.debug("Captured the Screenshot of Login");
		WebElement lognaftr = driver.findElement(LoginAftr);
		waits(driver, Duration.ofSeconds(10),LoginAftr );
		Click(lognaftr);
		log.debug("Clicked on Login");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void Exploring_Houses(String Locality) {
		WebElement menu = driver.findElement(Menu);
		waits(driver, Duration.ofSeconds(20), Menu);
		Click(menu);
		log.debug("Clicked on Menu");
		WebElement explore = driver.findElement(Explore);
		waits(driver, Duration.ofSeconds(10), Explore);
		Click(explore);
		log.debug("Clicked Explore");
		WebElement house = driver.findElement(Independenthouse);
		waits(driver, Duration.ofSeconds(10), Independenthouse);
		Click(house);
		log.debug("Clicked on IndependenceHouse");
		WebElement srch = driver.findElement(Search);
		waits(driver, Duration.ofSeconds(10), Search);
		Sendkeys(srch,Locality);
		log.debug("Entered the Locality Successfully");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		srch.sendKeys(Keys.ENTER);
		WebElement type = driver.findElement(Propertytype);
		waits(driver, Duration.ofSeconds(10), Propertytype);
		Click(type);
		log.debug("Clicked on Propertytype");
		WebElement selectinghouse = driver.findElement(House);
		waits(driver, Duration.ofSeconds(10),House );
		Click(selectinghouse);
		log.debug("Selected the Independent House");
		WebElement lookingfor = driver.findElement(Lookingfor);
		waits(driver, Duration.ofSeconds(10), Lookingfor);
		Click(lookingfor);
		log.debug("Clicked on Looking for");
		WebElement entirehouse = driver.findElement(EntireHouse);
		waits(driver, Duration.ofSeconds(10), EntireHouse);
		Click(entirehouse);
		log.debug("Selected Entire House");
		WebElement tenanttype = driver.findElement(Tenanttype);
		waits(driver, Duration.ofSeconds(10), Tenanttype);
		Click(tenanttype);
		log.debug("Clicked on Tenant type");
		WebElement family = driver.findElement(Family);
		waits(driver, Duration.ofSeconds(10),Family );
		Click(family);
		log.debug("Selected Family from Tenant Type");
		WebElement sort = driver.findElement(Sort);
		waits(driver, Duration.ofSeconds(10), Sort);
		Click(sort);
		log.debug("Clicked on Sort");
		WebElement low = driver.findElement(Price);
		waits(driver, Duration.ofSeconds(10),Price );
		Click(low);
		log.debug("Selected the Price from Low-High");
		WebElement filters = driver.findElement(Filters);
		waits(driver, Duration.ofSeconds(10),Filters );
		Click(filters);
		log.debug("Clicked on Filters");
		JavascriptExecutor js = (JavascriptExecutor)driver;	
		WebElement bhk = driver.findElement(Bhk);
		waits(driver, Duration.ofSeconds(10),Bhk );
		js.executeScript("arguments[0].click();",bhk);
		log.debug("Clicked on 2Bhk");
		WebElement applyfilter = driver.findElement(Applyfilters);
		waits(driver, Duration.ofSeconds(10), Applyfilters);
		js.executeScript("arguments[0].click();",applyfilter);	
		log.debug("Clicked on Apply filters");
		WebElement cancel = driver.findElement(Cancel);
		waits(driver, Duration.ofSeconds(10),Cancel );
		Click(cancel);
		log.debug("Clicked on Cancel");
		WebElement txt = driver.findElement(Text);
		waits(driver, Duration.ofSeconds(10), Text);
		Click(txt);
		String act = getText(txt);
		System.out.println(act);
		String exp = "Semi furnished 2 BHK in silver spring layout, munekolala";
		Assert.assertEquals(act, exp);
		log.debug("validation Successful");
		
	}
}
