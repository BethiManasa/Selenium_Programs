package Pages;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
public class DemoWebShop extends GenericMethods{
	WebDriver driver;
	public DemoWebShop(WebDriver driver) {
		this.driver = driver;
	}
//DemoWebshop Login
	By Loginicon = By.xpath("//a[text()='Log in']");
	By email = By.xpath("//input[@class='email']");
	By password = By.xpath("//input[@class='password']");
	By Login = By.xpath("//input[@class='button-1 login-button']");
//Filter Operations
	By Books = By.xpath("//ul[@class='top-menu']/child::li[1]/a");
	By Sortby = By.xpath("//select[@id='products-orderby']");
	By Display = By.xpath("//select[@id='products-pagesize']");
	By View =By.xpath("//select[@id='products-viewmode']");
	By Count = By.xpath("//div[@class='item-box']");
//Adding book to cart
	By Selectingbook = By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div[2]/div[2]/div[3]/div[1]/div/div[2]/h2/a");
	By Quantity = By.xpath("//input[@class='qty-input']");
	By Addcart = By.xpath("//input[@id='add-to-cart-button-13']");
	By Shoppingcart = By.xpath("//span[text()='Shopping cart']");
	By postalCode = By.xpath("//input[@class='zip-input']");
	By EstimateShipping = By.xpath("//input[@value='Estimate shipping']");
	By Checkbox = By.xpath("//input[@id='termsofservice']");
	By Checkout = By.xpath("//button[@id='checkout']");
//Checkout Process
	By Billing = By.xpath("//div[@id='billing-buttons-container']//child::input");
	By Shippingad = By.xpath("//div[@id='shipping-buttons-container']//child::input");
	By ShippingMethod = By.xpath("//div[@id='shipping-method-buttons-container']//child::input");
	By Paymentmethod = By.xpath("//div[@id='payment-method-buttons-container']//child::input");
	By Paymentinfo = By.xpath("//div[@id='payment-info-buttons-container']//child::input");
	By Confirm = By.xpath("//div[@id='confirm-order-buttons-container']//child::input");
	public void WebShop_Login(String Email, String Password) {
		WebElement lognicon  = driver.findElement(Loginicon); 
		waits(driver, Duration.ofSeconds(10), Loginicon);
	    Click(lognicon);
	    log.debug("Clicked on LoginIcon");
		WebElement mail  = driver.findElement(email); 
		waits(driver, Duration.ofSeconds(10), email);
		Sendkeys(mail, Email);
		  log.debug("Enter Email");
		WebElement pswd  = driver.findElement(password); 
		waits(driver, Duration.ofSeconds(10), password);
		Sendkeys(pswd, Password);
		  log.debug("Entered Password");
		try {
			takescreenshot("Demowebshop_Login");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement Logn  = driver.findElement(Login); 
		waits(driver, Duration.ofSeconds(10), Login);
		Click(Logn);
	   log.debug("Clicked on Login");
	   log.debug("Navigated to Homepage of DemoWebShop");
	}
	public void Filter_Operations(String Sorting,String Viewas) {
		WebElement books  = driver.findElement(Books); 
		waits(driver, Duration.ofSeconds(10), Books);
		Click(books);
		  log.debug("Clicked on Books");
		WebElement sort  = driver.findElement(Sortby); 
		waits(driver, Duration.ofSeconds(10), Sortby);
		Dropdown(sort,Sorting);
		  log.debug("Selected the sortby as Price-Low to high");
		WebElement display  = driver.findElement(Display); 
		waits(driver, Duration.ofSeconds(10), Display);
		Dropdown(display, "12");
		  log.debug("Selected display 12 per pages");
		WebElement view  = driver.findElement(View); 
		waits(driver, Duration.ofSeconds(10), View);
		Dropdown(view,Viewas);
		  log.debug("Selected view As List");
		List<WebElement>  list = driver.findElements(Count); 
		waits(driver, Duration.ofSeconds(10), Count);
		System.out.println("The number of items: "+list.size());
		  log.debug("The number of items are 6");
		  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		  
		
	}
	
	public void AddtoCart(String quantity,String SelectCountry,String PostalCode) {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement book  = driver.findElement(Selectingbook); 
		waits(driver, Duration.ofSeconds(20), Selectingbook);
		js.executeScript("arguments[0].click();", book);
		  log.debug("Clicked on computer and Internet Book ");
		WebElement quant  = driver.findElement(Quantity); 
		waits(driver, Duration.ofSeconds(10), Quantity);
		Clear(quant);
		Sendkeys(quant, quantity);
		log.debug("Entered the quantity of items");
		WebElement addcart  = driver.findElement(Addcart); 
		waits(driver, Duration.ofSeconds(10),Addcart );
		Click(addcart);
		log.debug("Clicked on Add to cart");
		//Actions act = new Actions(driver);
		WebElement shpcart  = driver.findElement(Shoppingcart); 
		waits(driver, Duration.ofSeconds(10), Shoppingcart);
		Click(shpcart);
		log.debug("Clicked on Shopping cartIcon");
		WebElement postcode  = driver.findElement(postalCode); 
		waits(driver, Duration.ofSeconds(10), postalCode);
		Clear(postcode);
		  log.debug("Enter the PostalCode");
		Sendkeys(postcode, PostalCode);
		WebElement estimate  = driver.findElement(EstimateShipping); 
		waits(driver, Duration.ofSeconds(10), EstimateShipping);
		Click(estimate);
		  log.debug("Clicked on Estimate Shipping");
		WebElement checkbox  = driver.findElement(Checkbox); 
		waits(driver, Duration.ofSeconds(10), Checkbox);
		Click(checkbox);
		  log.debug("Clicked on Checkboc to accept the terms&conditions");
		WebElement checkout  = driver.findElement(Checkout); 
		waits(driver, Duration.ofSeconds(10), Checkout);
		Click(checkout);
		  log.debug("Clicked on Checkout");

	}
	public void Checkout_Process() {
		WebElement billing  = driver.findElement(Billing); 
		waits(driver, Duration.ofSeconds(10), Billing);
		Click(billing);
		  log.debug("Clicked on continue Billing ");
		WebElement shippingad  = driver.findElement(Shippingad); 
		waits(driver, Duration.ofSeconds(10), Shippingad);
		Click(shippingad);
		  log.debug("Clicked on Continue Shipping Address");
		WebElement shippingmethod  = driver.findElement(ShippingMethod); 
		waits(driver, Duration.ofSeconds(10), ShippingMethod);
		Click(shippingmethod);
		  log.debug("Clicked on Continue Shipping method");
		WebElement paymentmethod  = driver.findElement(Paymentmethod); 
		waits(driver, Duration.ofSeconds(10), Paymentmethod);
		Click(paymentmethod);
		  log.debug("select COD as Payment method");
		WebElement payinfo  = driver.findElement(Paymentinfo); 
		waits(driver, Duration.ofSeconds(10), Paymentinfo);
		Click(payinfo);
		  log.debug("Clicked on continue with COD");
		WebElement confirm  = driver.findElement(Confirm); 
		waits(driver, Duration.ofSeconds(10), Confirm);
		Click(confirm);
		  log.debug("Clicked on Confirm");
		  log.debug("Order Successfully Placed");
		
		
	}
   
}
