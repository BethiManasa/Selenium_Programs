package Pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class CodeBeautify extends GenericMethods{
	WebDriver driver;
	public CodeBeautify(WebDriver driver) {
		this.driver = driver;
	}
    By login = By.xpath("//a[text()='Login']");
    By email = By.xpath("//input[@id='user-email']");
    By password = By.xpath("//input[@id='user-password']");
    By CloseAd = By.xpath("//button[@aria-label='Close Ad']");
    By LoginButton = By.xpath("//button[text()=' Login ']");
    By Search = By.xpath(" //input[@id='searchHomePage']");
    By Hashgenerator = By.xpath("//div[@id='app']/section[2]/div/a[4]");
    By Textarea = By.xpath("//textarea[@id='inputTextArea']");
    By Jsonformatter = By.xpath("(//a[text()='JSON Formatter'])[1]");
    By ConvertJson = By.xpath("//button[@class='btn btn-xs btn-outline btn-block dropdown-toggle']");
    By Sample= By.xpath("//a[@id='sampleDataBtn']");
    By CSV = By.xpath("//a[@onclick='jsonTocsv();']");
    By XML = By.xpath("//a[@onclick='jsonToxml();']");
    By JSonBeautifier = By.xpath("//div[@id='bs-example-navbar-collapse-1']/ul/li[1]/a");
    By File = By.xpath("//button[@title='Upload File']");
    public void CodeBeautifier_Login(String Email,String Password ) {
    	WebElement logn = driver.findElement(login);
    	waits(driver, Duration.ofSeconds(10), login);
    	Click(logn);
    	log.debug("Clicked on Login");
    	WebElement mail = driver.findElement(email);
    	waits(driver, Duration.ofSeconds(10), email);
    	Sendkeys(mail,Email );
    	log.debug("Entered Email");
    	WebElement pswd = driver.findElement(password);
    	waits(driver, Duration.ofSeconds(10), password);
    	Sendkeys(pswd,Password ); 
    	log.debug("Entered Password");
    	WebElement ad = driver.findElement(CloseAd);
    	waits(driver, Duration.ofSeconds(10), CloseAd);
    	Click(ad);
    	log.debug("Cancelled the Advertisement");
    	try {
			takescreenshot("CodeBeautify_Login");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	log.debug("Captured the Screenshot of Login");
    	WebElement lognbutton = driver.findElement(LoginButton);
    	waits(driver, Duration.ofSeconds(20), LoginButton);
    	Click(lognbutton);
    	log.debug("Clicked on Login Button");
    }
  
    public void Md2_Hash_Generator(String Searchtext,String Inputtext,String StringSpecialCharacters,String StringNumbers) {
    	WebElement search = driver.findElement(Search);
    	waits(driver, Duration.ofSeconds(10), Search);
    	Sendkeys(search,Searchtext);
    	log.debug("Entered the text:Cryptography");
    	search.sendKeys(Keys.ARROW_DOWN);
		search.sendKeys(Keys.ARROW_UP);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		search.sendKeys(Keys.ENTER);
		log.debug("Navigated to Cryptography Tools");
		String parent_Win = driver.getWindowHandle();            
		Set<String> s = driver.getWindowHandles();	
		Iterator<String> i = s.iterator();
		while(i.hasNext()) {
			String Child_Win = i.next();
			if(!(parent_Win.equals(Child_Win))) {
				driver.switchTo().window(Child_Win);
			}
		}
		log.debug("Redirected to Md2 Hash Generator Page");
		WebElement hashgenerator = driver.findElement(Hashgenerator);
    	waits(driver, Duration.ofSeconds(10), Hashgenerator);
    	Click(hashgenerator);
    	log.debug("Clicked on HashGenerator");
    	WebElement text1 = driver.findElement(Textarea);
    	waits(driver, Duration.ofSeconds(10), Textarea);
    	Sendkeys(text1, Inputtext);
    	log.debug("Entered the Simple JSONtext");
    	try {
			Thread.sleep(0);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    	try {
			takescreenshot("Hashgenerator_simpleString");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	log.debug("captured the Screenshot of formatted JSON of Simple String");
    	Clear(text1);
    	Sendkeys(text1, StringSpecialCharacters);
    	log.debug("Entered String with Special Characters");
    	try {
			takescreenshot("hashgenerator_SpecialcharactersString");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	log.debug("Captured the Screenshot of Formatted JSON with SpecialCharacters");
    	Clear(text1);
    	Sendkeys(text1, StringNumbers);
    	log.debug("Entered the JSON object String with Numbers");
    }
    public void JSON_Formatter() {
    	WebElement foramtter = driver.findElement(Jsonformatter);
    	waits(driver, Duration.ofSeconds(10), Jsonformatter);
    	Click(foramtter);
    	log.debug("Clicked on JSON Formatter");
    	String parent_Win = driver.getWindowHandle();            
		Set<String> s = driver.getWindowHandles();	
		Iterator<String> i = s.iterator();
		while(i.hasNext()) {
			String Child_Win = i.next();
			if(!(parent_Win.equals(Child_Win))) {
				driver.switchTo().window(Child_Win);
			}
		}
		log.debug("Redirected to JSON Formatter Page");
		WebElement sample = driver.findElement(Sample);
    	waits(driver, Duration.ofSeconds(10), Sample);
    	Click(sample);
    	log.debug("Clicked on Sample Code");
    	WebElement convert1 = driver.findElement(ConvertJson);
    	waits(driver, Duration.ofSeconds(20), ConvertJson);
    	try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	Click(convert1);
    	log.debug("Clicked on Json Converter");
    	WebElement csv = driver.findElement(CSV);
    	waits(driver, Duration.ofSeconds(10), CSV);
    	Click(csv);
    	log.debug("Selected JSON coverter to CSV");
    	WebElement convert2 = driver.findElement(ConvertJson);
    	waits(driver, Duration.ofSeconds(10), ConvertJson);
    	try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	Click(convert2);
    	log.debug("Clicked on Json Converter");
    	WebElement xml = driver.findElement(XML);
    	waits(driver, Duration.ofSeconds(10), XML);
    	Click(xml);
    	log.debug("Selected JSON coverter to Xml");
    	try {
			takescreenshot("Formatter_Xml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
    	log.debug("Captured the Screenshot of output with Xml Formatter");
    }
 
    public void JSON_Beautifier() throws AWTException {
    	WebElement beautifier = driver.findElement(JSonBeautifier);
    	waits(driver, Duration.ofSeconds(20), JSonBeautifier);
    	Click(beautifier);
    	log.debug("Clicked on JSON Beautifier");
    //waits(driver, Duration.ofSeconds(20), );
    	String parent_Win = driver.getWindowHandle();            
		Set<String> s = driver.getWindowHandles();	
		Iterator<String> i = s.iterator();
		while(i.hasNext()) {
			String Child_Win = i.next();
			if(!(parent_Win.equals(Child_Win))) {
				driver.switchTo().window(Child_Win);
			}
		}
		log.debug("Redirected to JSON Beautifier Page");
		WebElement file = driver.findElement(File);
		waits(driver, Duration.ofSeconds(30), File);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Click(file);
		
		   Robot r = new Robot();
		   StringSelection path=new StringSelection("\"C:\\Users\\BEMANASA\\Downloads\\jsonformatter.txt\"");
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(path, null);
          r.keyPress(KeyEvent.VK_CONTROL);
	       r.keyPress(KeyEvent.VK_V);
	       r.keyRelease(KeyEvent.VK_V);
	       r.keyRelease(KeyEvent.VK_CONTROL);
	       r.keyPress(KeyEvent.VK_ENTER);
	       r.keyRelease(KeyEvent.VK_ENTER);
    }
}
