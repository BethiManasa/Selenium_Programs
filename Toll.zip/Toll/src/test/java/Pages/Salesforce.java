package Pages;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Salesforce extends GenericMethods{
	WebDriver driver;
	public Salesforce(WebDriver driver) {
		this.driver = driver;
	}
    By UserName = By.xpath("//input[@name='username']");
    By PassWord = By.xpath("//input[@name='pw']");
    By login = By.xpath("//input[@name='Login']");
    By navigation = By.xpath("//button[@aria-label='Show Navigation Menu']");
    By Enquiry = By.xpath("//span[@data-aura-rendered-by='1472:0']");
    By Drop = By.xpath("//button[@data-aura-rendered-by='397:0']");
    
    
    public void Salesforce_Login() {
    	WebElement a = driver.findElement(UserName);
  	  waits(driver, Duration.ofSeconds(10), UserName);
  	  Sendkeys(a,"bala.subbarayudu@teamglobalexp.com.tollperf");
  	  log.debug("Entered the Username Successfully");
  	  WebElement b = driver.findElement(PassWord);
  	  waits(driver, Duration.ofSeconds(10), PassWord);
  	  Sendkeys(b, "Tge@12345" );
  	  log.debug("Entered the Password Successfully");
  	   try {
  		takescreenshot("Salesforce_Login");
  	} catch (IOException e1) {
  		// TODO Auto-generated catch block
  		e1.printStackTrace();
  	}
  	   WebElement e = driver.findElement(login);
  	   waits(driver, Duration.ofSeconds(10), login);
       Click(e);
       log.debug("Clicked on Login");  
//       WebElement menu = driver.findElement(navigation);
//  	   waits(driver, Duration.ofSeconds(10), navigation);
//       Click(menu);
       
     }
    	
    }
