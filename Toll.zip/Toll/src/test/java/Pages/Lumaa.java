package Pages;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Lumaa extends  GenericMethods{
	WebDriver driver;
	public Lumaa(WebDriver driver) {
		this.driver = driver;
	}
	By Signin = By.xpath("//html//body//div[2]//header//div[1]//div//ul//li[2]//a");
	By Email = By.xpath("//input[@name='login[username]']");
	By Password = By.xpath("//input[@name='login[password]']");
	By SigninBtn = By.xpath("//button[@class='action login primary']");
	By Mens =By.xpath("//a[@id='ui-id-5']/span[1]");
	By Bottoms = By.xpath("//a[@id='ui-id-18']/span[1]");
	By Pants = By.xpath("//a[@id='ui-id-23']/span");
	By Sortpant = By.xpath("//select[@id='sorter']");
	By Style = By.xpath("//div[@id='narrow-by-list']/div[1]/div[1]");
	By Trackpant = By.xpath("//div[@id='narrow-by-list']/div[1]/div[2]/ol/li[5]/a");
	By Size = By.xpath("//div[@id='narrow-by-list']/div[1]/div[1]");
	By Thirtytwo = By.xpath("//div[@id='option-label-size-143-item-175']");
	By Color = By.xpath("//div[@id='narrow-by-list']/div[2]/div[1]");
	By Black = By.xpath("//div[@option-id='49']");
	By Material = By.xpath("//div[@id='narrow-by-list']/div[4]/div[1]");
	By Polyster = By.xpath("//div[@id='narrow-by-list']/div[4]/div[2]/ol/li[7]/a");
	By Shorts = By.xpath("//a[@id='ui-id-24']/span");
	By Sortby = By.xpath("(//select[@class='sorter-options'])[1]");
	By Workoutpant = By.xpath("(//ol[@class='items'])[1]/li[4]");
	By Gray = By.xpath("//div[@option-id='52']");
	By Gymshort = By.xpath("//main[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[3]/div/div/strong/a");
	By Addcart = By.xpath("//button[@title='Add to Cart']");
	By Size1 = By.xpath("//div[@id='option-label-size-143-item-175']");
	By Graycolor = By.xpath("//div[@id='option-label-color-93-item-52']");
	By Quantity = By.xpath("//input[@name='qty']");
	By Cartbtn = By.xpath("//button[@title='Add to Cart']");
	By ShoppinCart= By.xpath("//a[@class='action showcart']");
	By View = By.xpath("//span[text()='View and Edit Cart']");
	By Quantity2 = By.xpath("//input[@name='cart[715186][qty]']");
	By Update = By.xpath("//span[text()='Update Shopping Cart']");
	By Proceed = By.xpath("//span[text()='Proceed to Checkout']");
	By Next = By.xpath("//button[@data-role='opc-continue']");
	By PlaceOrder = By.xpath("//span[text()='Place Order']");
	public void Luma_Login() {
		WebElement sign = driver.findElement(Signin);
		waits(driver, Duration.ofSeconds(20),Signin );
		Click(sign);
		log.debug("Clicked on Sigin");
		WebElement email = driver.findElement(Email);
		waits(driver, Duration.ofSeconds(10),Email );
		Sendkeys(email, "abc.123@gmail.com");
		log.debug("Entered Email Successfully");
		//Sendkeys(email, Emaill);
		WebElement pswd = driver.findElement(Password);
		waits(driver, Duration.ofSeconds(10),Password );
	   Sendkeys(pswd, "abc@1159");
	   log.debug("Entered Password Successfully");
		//Sendkeys(pswd, PassWord);
	   try {
		takescreenshot("Luma_Login");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		WebElement signbtn = driver.findElement(SigninBtn);
		waits(driver, Duration.ofSeconds(10),SigninBtn );
		Click(signbtn);	
		log.debug("Clicked Signin Button");
	}
	public void Exploring_MensBottomsPants() {
		try {
			Thread.sleep(5000);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Actions act = new Actions(driver);
		WebElement men = driver.findElement(Mens);
		waits(driver, Duration.ofSeconds(10),Mens );
		act.moveToElement(men).build().perform();
		log.debug("Mouse hovered on men");
		WebElement bottom = driver.findElement(Bottoms);
		waits(driver, Duration.ofSeconds(10),Bottoms );
		act.moveToElement(bottom).build().perform();
		log.debug("Mouse hovered on Buttoms");
		WebElement pant = driver.findElement(Pants);
		waits(driver, Duration.ofSeconds(10),Pants );
		Click(pant);
		log.debug("Clicked on Pant");
		WebElement srtpant = driver.findElement(Sortpant);
		waits(driver, Duration.ofSeconds(10),Sortpant );
		dropdown(srtpant, "name");
		log.debug("Clicked on Sortby and selected as per Product name");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement style = driver.findElement(Style);
		waits(driver, Duration.ofSeconds(10),Style );
		Click(style);
		log.debug("Clicked on Style");
		WebElement track = driver.findElement(Trackpant);
		waits(driver, Duration.ofSeconds(10),Trackpant);
		Click(track);
		log.debug("Selected Trackpants");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement size = driver.findElement(Size);
		waits(driver, Duration.ofSeconds(10),Size );
		Click(size);
		log.debug("Clicked on Size");
		WebElement two = driver.findElement(Thirtytwo);
		waits(driver, Duration.ofSeconds(30),Thirtytwo );
		Click(two);
		log.debug("Selcted size 32");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement color = driver.findElement(Color);
		waits(driver, Duration.ofSeconds(10),Color );
		Click(color);
		log.debug("Clicked on Colour");
		WebElement black = driver.findElement(Black);
		waits(driver, Duration.ofSeconds(30),Black );
		Click(black);
		log.debug("Selected Black Colour");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement material = driver.findElement(Material);
		waits(driver, Duration.ofSeconds(30),Material );
		Click(material);
		log.debug("Clicked on material Type");
		WebElement polyster = driver.findElement(Polyster);
		waits(driver, Duration.ofSeconds(30),Polyster );
		Click(polyster);
		log.debug("Selected Polyster");
	}
	public void MensBottoms_Shorts() {
		Actions act1 = new Actions(driver);
		WebElement men1 = driver.findElement(Mens);
		waits(driver, Duration.ofSeconds(10),Mens );
		act1.moveToElement(men1).build().perform();
		log.debug("Mouse hovered on Men");
		WebElement bottom1 = driver.findElement(Bottoms);
		waits(driver, Duration.ofSeconds(10),Bottoms );
		act1.moveToElement(bottom1).build().perform();
		log.debug("Mouse hovered on Bottoms");
		WebElement shorts = driver.findElement(Shorts);
		waits(driver, Duration.ofSeconds(10),Shorts );
		Click(shorts);
		log.debug("Clicked Shorts");
		WebElement sortt = driver.findElement(Sortby);
		waits(driver, Duration.ofSeconds(10), Sortby);
		dropdown(sortt, "price");
		log.debug("Clicked on Sortby option and Selected as per Price");
		WebElement style = driver.findElement(Style);
		waits(driver, Duration.ofSeconds(10),Style );
		Click(style);
		log.debug("Clicked on Style");
		WebElement workout = driver.findElement(Workoutpant);
		waits(driver, Duration.ofSeconds(10),Workoutpant );
		Click(workout);
		log.debug("Selected Workout pants");
		WebElement size = driver.findElement(Size);
		waits(driver, Duration.ofSeconds(10),Size );
		Click(size);
		log.debug("Clicked on Size");
		WebElement two = driver.findElement(Thirtytwo);
		waits(driver, Duration.ofSeconds(30),Thirtytwo );
		Click(two);
		log.debug("Seleted the Size 32");
		WebElement color = driver.findElement(Color);
		waits(driver, Duration.ofSeconds(10),Color );
		Click(color);
		log.debug("Clicked on Colour");
//		WebElement gray = driver.findElement(Gray);
//		waits(driver, Duration.ofSeconds(30),Gray );
//		Click(gray);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement pierceshort = driver.findElement(Gymshort);
		waits(driver, Duration.ofSeconds(50),Gymshort);
		js.executeScript("arguments[0].click();",pierceshort );
		log.debug("Selected Pierce Gym Short");
		WebElement cart = driver.findElement(Addcart);
		waits(driver, Duration.ofSeconds(30),Addcart );
        js.executeScript("arguments[0].click();", cart);
        log.debug("Clicked on Add to cart");
        WebElement size1 = driver.findElement(Size1);
		waits(driver, Duration.ofSeconds(30),Size1 );
		Click(size1);
		log.debug("Selected the Size 32");
		WebElement graycolo = driver.findElement(Graycolor);
		waits(driver, Duration.ofSeconds(30),Graycolor );
		Click(graycolo);
		log.debug("Selcted Gray Colour");
		WebElement quant = driver.findElement(Quantity);
		waits(driver, Duration.ofSeconds(30),Quantity );
		Clear(quant);
		Sendkeys(quant, "1");
		log.debug("Entered Quantity one into quantity field");
		WebElement btn = driver.findElement(Cartbtn);
		waits(driver, Duration.ofSeconds(30),Cartbtn );
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Click(btn);
		log.debug("Clicked on Add to cart Button");
		WebElement shopcart = driver.findElement(ShoppinCart);
		waits(driver, Duration.ofSeconds(30),ShoppinCart );
		Click(shopcart);
		log.debug("Clicked on Shopping Cart");
		WebElement view = driver.findElement(View);
		waits(driver, Duration.ofSeconds(50), View);
		Click(view);
		log.debug("Clicked on View and Edit");
		WebElement quant2 = driver.findElement(Quantity2);
		waits(driver, Duration.ofSeconds(30), Quantity2);
		Clear(quant2);
		Sendkeys(quant2, "1");
		log.debug("Entered the Quantity one into Quantity field");
		WebElement update = driver.findElement(Update);
		waits(driver, Duration.ofSeconds(30),Update );
		Click(update);
		log.debug("CLicked on Update");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement checkout = driver.findElement(Proceed);
		waits(driver, Duration.ofSeconds(30),Proceed );
		Click(checkout);
		log.debug("Clicked on Proceed to Checkout");
		WebElement next = driver.findElement(Next);
		waits(driver, Duration.ofSeconds(30),Next );
		js.executeScript("arguments[0].click();", next);
		log.debug("Clicked on Next button");
		WebElement order = driver.findElement(PlaceOrder);
		waits(driver, Duration.ofSeconds(30),PlaceOrder );
		js.executeScript("arguments[0].click();", order);
		log.debug("Clicked on PlaceOrder");
		log.debug("Order Placed Successfully and Order Number is Created");		
	}
	
}
