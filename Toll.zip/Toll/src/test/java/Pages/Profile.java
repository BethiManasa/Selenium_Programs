package Pages;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
public class Profile extends GenericMethods{
	WebDriver driver;
	public Profile(WebDriver driver) {
		this.driver = driver;
	}
	By next = By.xpath("//a[@title='NEXT']");
	By username = By.id("username");
	By Continue_1 = By.xpath("//button[@role='button']");
	By Login = By.xpath("//button[@data-dgat='LogIn-32c']");
	By Password = By.xpath("//div[@class='guts-p-b-quart account__textfield']//child::input");
	By Continue_2 = By.xpath("//span[@class='df-button-wrapper']//child::div");
	By profile = By.xpath("//a[text()=' Profile ']");
	By skills = By.id("ngb-nav-1");
	By addskill = By.xpath("//div[text()='Add Skill']");
	By select = By.xpath("(//ul[@class='guts-m-t-half ng-star-inserted']//child::li[7]//child::div)[2]");
	By AddSkills = By.xpath("//span[text()=' Add Skills ']");
	By Collections = By.xpath("//a[text()='Collection']");
	By Experiences = By.xpath(" //span[text()=' Experiences ']");
	By Text1 = By.xpath("//span[text()='Add Experiences to your collection']");
	By Achievements = By.xpath(" //span[text()=' Achievements ']");
	By Text2 = By.xpath("//span[text()='Add Achievements to your collection']");
	By Pathways = By.xpath("//div[@class='l_flex l_flex-justify']//child::button[4]//span");
	By Plan = By.xpath("//span[text()=' Plans ']");
	By Activity = By.xpath("//div[@class='tabnav__list']//child::div[4]/a");
	public void Profile_Exploring() {
		WebElement nxt = driver.findElement(next);
		waits(driver, Duration.ofSeconds(10),next );
		Click(nxt);
		log.debug("Clicked on Next in the Talent Portal");
		String parent_win = driver.getWindowHandle();     
		Set<String> set = driver.getWindowHandles();     
		Iterator<String> I = set.iterator();
	   while(I.hasNext()){
		   String child_win =I.next();
		   if(!(parent_win.equals(child_win))) {
			   driver.switchTo().window(child_win);
		   }
		}
		WebElement user = driver.findElement(username);
		waits(driver, Duration.ofSeconds(10),username );
		Sendkeys(user, "bethi.manasa@capgemini.com");
		log.debug("Entered user name is:bethi.manasa@capgemini.com");
		WebElement con =driver.findElement(Continue_1);
		waits(driver, Duration.ofSeconds(10),Continue_1 );
		Click(con);
		log.debug("Clicked on Continue");
		WebElement logn = driver.findElement(Login);
		waits(driver, Duration.ofSeconds(10),Login );
		Click(logn);
		log.debug("Clicked on Login");
		WebElement password = driver.findElement(Password);
		waits(driver, Duration.ofSeconds(10),Password );
		Sendkeys(password, "manasa@1159");
		log.debug("The entered password is:manasa@1159");
		try {
			takescreenshot("Login");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.debug("Screenshot for Login is Succesful");
		WebElement Conti = driver.findElement(Continue_2);
		waits(driver, Duration.ofSeconds(10),Continue_2 );
			Click(Conti);
		WebElement pro = driver.findElement(profile);
		waits(driver, Duration.ofSeconds(10),profile );
		Click(pro);
		log.debug("Clicked on Profile");
		WebElement skill = driver.findElement(skills);
		waits(driver, Duration.ofSeconds(10),skills );
		Click(skill);
		log.debug("Clicked on Skills");
		WebElement add = driver.findElement(addskill);
		waits(driver, Duration.ofSeconds(10),addskill );
		Click(add);
		log.debug("Clicked on addSkills");
		WebElement se = driver.findElement(select);
		waits(driver, Duration.ofSeconds(10),select );
		Click(se);
		log.debug("Selected the Skill Successfully");
		WebElement Adding = driver.findElement(AddSkills);
		waits(driver, Duration.ofSeconds(10), AddSkills );
		Click(Adding);
		log.debug("Clicked on AddSkills");
		WebElement collect = driver.findElement(Collections);
		waits(driver, Duration.ofSeconds(10),Collections );
		Click(collect);
//		JavascriptExecutor js = (JavascriptExecutor)driver;
//		js.executeScript("window.scrollBy(0,800)");
		log.debug("Clicked on Collections");
		WebElement experience = driver.findElement(Experiences);
		waits(driver, Duration.ofSeconds(10),Experiences );
		Click(experience);
//		WebElement text1 = driver.findElement(Text1);
//		waits(driver, Duration.ofSeconds(10),Text1 );
//		String a = getText(text1);
//		System.out.println("Text after Clicking Experience:"+a);
//		log.debug("Clicked on Experiences");
		WebElement achieve = driver.findElement(Achievements);
		waits(driver, Duration.ofSeconds(10),Achievements );
		Click(achieve);
		WebElement text2 = driver.findElement(Text2);
		waits(driver, Duration.ofSeconds(10),Text2 );
		String b = getText(text2);
		System.out.println("Text After Clicking Achievements:" +b);
		log.debug("Clicked on Achievements");
		WebElement path = driver.findElement(Pathways);
		waits(driver, Duration.ofSeconds(10),Pathways );
		Click(path);
		log.debug("Clicked on Pathways");
		WebElement plan = driver.findElement(Plan);
		waits(driver, Duration.ofSeconds(10),Plan );
		Click(plan);
		log.debug("Clicked on Plan");
		WebElement activity = driver.findElement(Activity);
		waits(driver, Duration.ofSeconds(10),Activity );
		Click(activity);
		log.debug("Clicked on Activity");
		
		
		
	}
	
	

}
