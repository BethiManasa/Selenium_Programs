package Pages;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MyBookings extends GenericMethods{
	WebDriver driver;
	public MyBookings(WebDriver driver) {
		this.driver = driver;
	}
	By Login = By.xpath("(//div[@class='m-auto py-0.8p'])[2]//div");
	By MobileNo = By.xpath("//input[@id='signUp-phoneNumber']");
	By radio = By.xpath("(//input[@name='loginType'])[2]");
	By Password = By.xpath("//input[@id='login-signup-form__password-input']");
    By Continue = By.xpath("//button[@id='signUpSubmit']");
    By Menu = By.xpath("//div[@id='main-menu']/div[1]/img");
    By Rentalagreement = By.xpath("//div[@id='main-menu']/div[2]/a[2]");
    By Bookings = By.xpath("//button[@class='z-50 items-center hidden px-2 py-1 cd:flex']//span");
//   By Select = By.xpath("//*[@id=\"app\"]/div/div/div/div/div[2]/div/header/nav/div[2]/div[1]/button/span[2]");
    By City = By.xpath("//div[@id='modal-root']/div/div[2]/div/div/div/div[2]/div[2]/div[1]/div");
  //  By Booknow = By.xpath("//button[text()='Book Now']");
   // By onlinerental = By.xpath("(//div[@class='font-semi-bold service-details-header'])[1]//span[1]");
    By Stamp = By.xpath("//div[@class='relative grid grid-cols-2 gap-4 md:gap-5 md:grid-cols-3']/div[3]");
    By StampAmount = By.xpath("(//div[@class='nb-stampdutyselector-container']//div)[2]");
    By Calendar = By.xpath("//input[@placeholder='Select Day']");
    By Date = By.xpath("(//div[@aria-label='day-29'])[2]");
    By Tenant = By.xpath("//div[@class='user-type-container mb-2']//div[1]");
    By Propertydetails = By.xpath("//div[@id='appPortal']/div/div[2]/div/div/div/div[1]/div/div[3]/div[3]/div/div[2]");
    By floor = By.xpath("//div[@id='ls-documentforms-floorNumber-nbInput']/div/div[2]");
    By Bhk = By.xpath("//div[@id='ls-documentforms-bhkType-nbInput']/div/div[2]");
    By Selectproperty = By.xpath("(//div[@aria-hidden='true'])[3]");
    By Flat = By.xpath("//div[text()='Apartment/Flat']");
    By Flatnumber = By.xpath("//input[@placeholder='Enter Number']");
    By Buildingname = By.xpath("//input[@placeholder='Building Name']");
    By Location = By.id("ls-documentforms-locality-nbInput");
    By Pincode = By.id("ls-documentforms-pincode-nbInput");
    
    public void NoBroker_Login() {
    	WebElement log = driver.findElement(Login);
    	waits(driver, Duration.ofSeconds(20), Login);
    	Click(log);
    	WebElement mobile = driver.findElement(MobileNo);
    	waits(driver, Duration.ofSeconds(20), MobileNo);
    	Sendkeys(mobile, "9030378300");
    	WebElement Radio = driver.findElement(radio);
    	waits(driver, Duration.ofSeconds(20), radio);
    	Click(Radio);
    	WebElement password = driver.findElement(Password);
    	waits(driver, Duration.ofSeconds(20), Password);
    	Sendkeys(password, "Manasa@1159");
    	WebElement contnue = driver.findElement(Continue);
    	waits(driver, Duration.ofSeconds(30), Continue);
    	Click(contnue);
    }
    
    public void Bookings() {
    	WebElement element = driver.findElement(Menu);
    	waits(driver, Duration.ofSeconds(30), Menu);
    	JavascriptExecutor executor = (JavascriptExecutor)driver;
    	executor.executeScript("arguments[0].click();", element);
    	//Click(menu);
//    	JavascriptExecutor js = (JavascriptExecutor)driver;
//    	js.executeScript("window.scrollBy(0,700)");
    	WebElement rental = driver.findElement(Rentalagreement);
    	waits(driver, Duration.ofSeconds(20), Rentalagreement);
    	executor.executeScript("arguments[0].click();", rental);
    	
//    	Click(rental);
//    	WebElement sel = driver.findElement(Select);
//    	waits(driver, Duration.ofSeconds(20), Select);
//    	Click(sel);
    	WebElement ct = driver.findElement(City);
    	waits(driver, Duration.ofSeconds(20), City);
    	Click(ct);
    	WebElement stamp = driver.findElement(Stamp);
    	waits(driver, Duration.ofSeconds(20), Stamp);
    	Click(stamp);
    	WebElement amount = driver.findElement(StampAmount);
    	waits(driver, Duration.ofSeconds(20), StampAmount);
    	Click(amount);	
    	WebElement calen = driver.findElement(Calendar);
    	waits(driver, Duration.ofSeconds(10), Calendar);
    	Click(calen);
    	WebElement date = driver.findElement(Date);
    	waits(driver, Duration.ofSeconds(10), Date);
    	Click(date);	
    	WebElement tenant = driver.findElement(Tenant);
    	waits(driver, Duration.ofSeconds(10), Tenant);
    	Click(tenant);
    	WebElement propdet = driver.findElement(Propertydetails);
    	waits(driver, Duration.ofSeconds(30), Propertydetails);
    	Click(propdet);
    	WebElement flor = driver.findElement(floor);
    	waits(driver, Duration.ofSeconds(20), floor);
    	Click(flor);
    	WebElement bhk = driver.findElement(Bhk);
    	waits(driver, Duration.ofSeconds(20), Bhk);
    	Click(bhk);	
    	WebElement select = driver.findElement(Selectproperty);
    	waits(driver, Duration.ofSeconds(20), Selectproperty);
    	Click(select);
    	WebElement flat = driver.findElement(Flat);
    	waits(driver, Duration.ofSeconds(20), Flat);
    	Click(flat);
    	WebElement num = driver.findElement(Flatnumber);
    	waits(driver, Duration.ofSeconds(20), Flatnumber);
    	Sendkeys(num, "3-42");
    	WebElement buildname = driver.findElement(Buildingname);
    	waits(driver, Duration.ofSeconds(10), Buildingname);
    	Sendkeys(buildname, "Manohara");
    	WebElement loctn = driver.findElement(Location);
    	waits(driver, Duration.ofSeconds(20), Location);
        Sendkeys(loctn, "BEML");
    	WebElement pin = driver.findElement(Pincode);
    	waits(driver, Duration.ofSeconds(20), Pincode);
    	Sendkeys(pin, "560066");
    	
    	
    	
    }
    
}
