package Pages;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Tests.Driver;

public class GenericMethods extends Driver {
		public void Sendkeys(WebElement ele, String text) {
			ele.sendKeys(text);
			
		}
		public void Click(WebElement element) {
			element.click();
			
		}
	    public String getText(WebElement ele) {
			return ele.getText();

	}
	    public void Dropdown(WebElement elem, String s) {
			Select se = new Select(elem);
			se.selectByVisibleText(s);	
		}
	    public void dropdown(WebElement elem, String s) {
			Select se = new Select(elem);
			se.selectByValue(s);
		}
	    public static void takescreenshot(String fileName) throws IOException {
			File file =   ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(file,new File("C://Users//BEMANASA//eclipse-workspace//Toll//Screenshots//" +fileName+ ".jpg"));
			} 
	    public void Clear(WebElement element) {
			element.clear();
			
		}
	    public void waits(WebDriver driver, Duration time,By loc) {
			WebDriverWait wait = new WebDriverWait(driver,time);
			wait.until(ExpectedConditions.visibilityOfElementLocated(loc));
		}

}
