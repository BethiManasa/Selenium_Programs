package Pages;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class TravelConsent extends GenericMethods {
	public static WebDriver driver;
	public TravelConsent(WebDriver driver) {
		this.driver = driver;	
	}
	By documents = By.xpath("//li[@class='documents_lien_menu dropdown']/a");
    By personal = By.xpath("//div[@id='menu']/nav/ul/li[2]/ul/li[2]/a");
    By Form = By.xpath("//a[text()='Travel Consent Form']");
    By Filltemplate = By.xpath("//html//body//div[1]//div[2]//div[2]//div[1]/a");
    By Travellingwith = By.xpath("//select[@name='travel_accompaniment']");
    By Next1 = By.xpath("//button[@name='suivant']");
    By Next2 = By.xpath("//button[@name='suivant']");
    By Travelparent = By.xpath("//input[@name='only_travel_parent_name']");
    By TravelAddress= By.xpath("//input[@name='only_travel_parent_address']");
    By Contactnum = By.xpath("//input[@name='only_travel_parent_phone_number']");
    By Next3 = By.xpath("//button[@name='suivant']");
    By Parentemail = By.xpath("//input[@name='only_travel_parent_email_address']");
    By Next4 = By.xpath("//button[@name='suivant']");
	By NumChildren = By.xpath("//select[@name='number_of_children']");
	By Next5 = By.xpath("//button[@name='suivant']");
    By FirstChildname = By.xpath("//input[@name='first_child_name']");
    By FirstChildgender = By.xpath("//select[@name='first_child_gender']");
    By Datepicker = By.xpath("//input[@name='first_child_birth_date']");
    By Month = By.xpath("//select[@class='ui-datepicker-month']");
    By year = By.xpath("//select[@class='ui-datepicker-year']");
    By Date = By.xpath("//a[text()='23']");
    By Next6 = By.xpath("//button[@name='suivant']");
    By EBirthplace = By.xpath("//input[@name='first_child_birth_location']");
    By Next7 = By.xpath("//button[@name='suivant']");
    By Epassport = By.xpath("//input[@name='first_child_passport_number']");
    By Next8 = By.xpath("//button[@name='suivant']");
    By SecondChild = By.xpath("//input[@name='second_child_name']");
    By Gender1 = By.xpath("//div[text()='Female']");
    By DatePicker1 = By.xpath("//input[@name='second_child_birth_date']");
    By Month2 =By.xpath("//select[@class='ui-datepicker-month']");
    By Year2 = By.xpath("//select[@class='ui-datepicker-year']");
    By Date2 = By.xpath("//a[text()='22']");
    By Next9 = By.xpath("//button[@name='suivant']");
    By secondplace =By.xpath("//input[@name='second_child_birth_location']");
    By Next10 = By.xpath("//button[@name='suivant']");
    By secondpassport =By.xpath("//input[@name='second_child_passport_number']");
    By Next11 = By.xpath("//button[@name='suivant']");
    By destination = By.xpath("//input[@name='travel_destination']");
    By Travelstart = By.xpath("//input[@name='travel_date_start']");
    By Startdate = By.xpath("//a[text()='29']");
    By TravelEnd = By.xpath("//input[@name='travel_date_end']");
    By Endmonth = By.xpath("//select[@class='ui-datepicker-month']");
    By Enddate = By.xpath("//a[@data-date='7']");
    By Next12 = By.xpath("//button[@name='suivant']");
    By Next13 = By.xpath("//button[@name='suivant']");
    By Medicalneed =By.xpath("//textarea[@name='children_medical_needs_description']");
    By Next14 = By.xpath("//button[@name='suivant']");
    By Next15 = By.xpath("//button[@name='suivant']");
    By Next16 = By.xpath("//button[@name='suivant']");
    By Next17 = By.xpath("//button[@name='suivant']");
    By documentsattched = By.xpath("//textarea[@id='describe_doc']");
    By Customise = By.xpath("//span[@class='comment_modifier open-dialog']");
    By ok = By.xpath("(//div[text()='OK'])[2]");
    By Save = By.xpath("//input[@name='sauvegarder']");
    By Email = By.xpath("//input[@type='email']");
    By Account = By.xpath("//label[@id='id_mot_de_passe_existe_oui']");
    By Password = By.xpath("//input[@type='password']");
    By Login = By.xpath("//button[text()='Login (secure server)']");
    By Edit = By.xpath("//div[@id='tableArchivedDocuments']/table/tbody/tr/td[3]/a");
    By Finish = By.xpath("//button[@name='suivant']");    
    
	public void TraveConsentForm(String TravellingWith,String Parentname,String ParentAddress,String Parentcontactnum,String ParentEmail,String FirstChildName,String FirstChildGender,String Monthh,String ElderPlace,String ElderPassport,
			   String SecondChildName,String Monthhh,String SecondPlace,String SecondPassport,String Destination,String TravelEndMonth,String Documents,String Emaill, String PassWord) {
		WebElement doc = driver.findElement(documents);
		waits(driver, Duration.ofSeconds(10), documents);
		Actions act = new Actions(driver);
		act.moveToElement(doc).perform();
		log.debug("Moved to Element Document");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement persnal = driver.findElement(personal);
		waits(driver, Duration.ofSeconds(10), personal);
		Click(persnal);
		log.debug("Clicked on Personal");
		WebElement form = driver.findElement(Form);
		waits(driver, Duration.ofSeconds(10), Form);
		Click(form);
		log.debug("Clicked on Travel Consent Form");
		WebElement template = driver.findElement(Filltemplate);
		waits(driver, Duration.ofSeconds(10), Filltemplate);
		Click(template);
		log.debug("Clicked on Fill out the Template");
		WebElement travellingwith = driver.findElement(Travellingwith);
		waits(driver, Duration.ofSeconds(10), Travellingwith);
		Dropdown(travellingwith,TravellingWith );
		log.debug("Enter the Name of the Parent Travelling with");
		WebElement next1 = driver.findElement(Next1);
		waits(driver, Duration.ofSeconds(10), Next1);
		Click(next1);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.debug("Clicked on Next");
		WebElement next2 = driver.findElement(Next2);
		waits(driver, Duration.ofSeconds(10), Next2);
		Click(next2);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement pname = driver.findElement(Travelparent);
		waits(driver, Duration.ofSeconds(10), Travelparent);
		Sendkeys(pname, Parentname);
		log.debug("Entered the Name of Parent");
		WebElement paddress = driver.findElement(TravelAddress);
		waits(driver, Duration.ofSeconds(10), TravelAddress);
		Sendkeys(paddress, ParentAddress);
		log.debug("Entered the Address of Parent");
		WebElement contactnum = driver.findElement(Contactnum);
		waits(driver, Duration.ofSeconds(10), Contactnum);
	     Sendkeys(contactnum, Parentcontactnum);
		log.debug("Entered the Contact Number of the Parent");
		WebElement next3 = driver.findElement(Next3);
		waits(driver, Duration.ofSeconds(10), Next3);
		Click(next3);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.debug("Clicked on Next");
		WebElement pemail = driver.findElement(Parentemail);
		waits(driver, Duration.ofSeconds(10), Parentemail);
	Sendkeys(pemail, ParentEmail);
		log.debug("Entered Parent Email");
		WebElement next4 = driver.findElement(Next4);
		waits(driver, Duration.ofSeconds(10), Next4);
		Click(next4);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.debug("Clicked on Next");
		WebElement child = driver.findElement(NumChildren);
		waits(driver, Duration.ofSeconds(10), NumChildren);
	    Dropdown(child, "2");
		log.debug("Selected how many children Travelling");
		WebElement next5 = driver.findElement(Next5);
		waits(driver, Duration.ofSeconds(10), Next5);
		Click(next5);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.debug("Clicked on Next");
		WebElement Fname = driver.findElement(FirstChildname);
		waits(driver, Duration.ofSeconds(10), FirstChildname);
		Sendkeys(Fname, FirstChildName);
		log.debug("Entered Elder Child FullName");
		WebElement Fgender = driver.findElement(FirstChildgender);
		waits(driver, Duration.ofSeconds(10), FirstChildgender);
	    Sendkeys(Fgender, FirstChildGender);
		log.debug("Entered Elder Child Gender");
		WebElement datepic = driver.findElement(Datepicker);
		waits(driver, Duration.ofSeconds(10), Datepicker);
		Click(datepic);
		log.debug("Clicked on DatePicker");
		WebElement month = driver.findElement(Month);
		waits(driver, Duration.ofSeconds(10), Month);
		Dropdown(month, Monthh);
		log.debug("Selcted the month");
		WebElement yr = driver.findElement(year);
		waits(driver, Duration.ofSeconds(10), year);
		Dropdown(yr, "2000");
		log.debug("Selcted the Year");
		WebElement dateee = driver.findElement(Date);
		waits(driver, Duration.ofSeconds(10), Date);
		Click(dateee);
		log.debug("Clicked the date:23/02/2000");
		WebElement next6 = driver.findElement(Next6);
		waits(driver, Duration.ofSeconds(10), Next6);
		Click(next6);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement birthplace = driver.findElement(EBirthplace);
		waits(driver, Duration.ofSeconds(10), EBirthplace);
		Sendkeys(birthplace, ElderPlace);
		log.debug("Entered Birthplace of Elder Child");
		WebElement next7 = driver.findElement(Next7);
		waits(driver, Duration.ofSeconds(10), Next7);
		Click(next7);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement epassport = driver.findElement(Epassport);
		waits(driver, Duration.ofSeconds(10), Epassport);
	    Sendkeys(epassport, ElderPassport);
		log.debug("Entered Passport Number of Elder Child");
		WebElement next8 = driver.findElement(Next8);
		waits(driver, Duration.ofSeconds(10), Next8);
		Click(next8);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement child2 = driver.findElement(SecondChild);
		waits(driver, Duration.ofSeconds(10), SecondChild);
		Sendkeys(child2, SecondChildName);
		log.debug("Entered the FullName of Child_2");
		WebElement gender2 = driver.findElement(Gender1);
		waits(driver, Duration.ofSeconds(10), Gender1);
		Click(gender2);
		log.debug("Selcted the Gender of Child_2");
		WebElement datepickk = driver.findElement(DatePicker1);
		waits(driver, Duration.ofSeconds(10), DatePicker1);
		Click(datepickk);
		log.debug("Clicked on DatePicker");
		WebElement month2 = driver.findElement(Month2);
		waits(driver, Duration.ofSeconds(10), Month2);
	   Sendkeys(month2, Monthhh);
		log.debug("Selected the Month");
		WebElement yrr = driver.findElement(Year2);
		waits(driver, Duration.ofSeconds(10), Year2);
		Dropdown(yrr, "2002");
		log.debug("Selcted the Year");
		WebElement date2 = driver.findElement(Date2);
		waits(driver, Duration.ofSeconds(10), Date2);
		Click(date2);
		log.debug("Clicked on Date::22/11/2002");
		WebElement next9 = driver.findElement(Next9);
		waits(driver, Duration.ofSeconds(10), Next9);
		Click(next9);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement secndplace = driver.findElement(secondplace);
		waits(driver, Duration.ofSeconds(10), secondplace);
	     Sendkeys(secndplace, SecondPlace);
		log.debug("Enter Birtplace of Child_2");
		WebElement next10 = driver.findElement(Next10);
		waits(driver, Duration.ofSeconds(10), Next10);
		Click(next10);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.debug("Clicked on Next");
		WebElement secndpassport = driver.findElement(secondpassport);
		waits(driver, Duration.ofSeconds(10), secondpassport);
	  Sendkeys(secndpassport, SecondPassport);
		log.debug("Entered the Passport Number of Child_2");
		WebElement next11 = driver.findElement(Next11);
		waits(driver, Duration.ofSeconds(10), Next11);
		Click(next11);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement dest = driver.findElement(destination);
		waits(driver, Duration.ofSeconds(10), destination);
		Sendkeys(dest, Destination);
		log.debug("Entered the Destination Palce:Paris");
		WebElement travelstrt = driver.findElement(Travelstart);
		waits(driver, Duration.ofSeconds(10), Travelstart);
	   Click(travelstrt);
		log.debug("Clicked on Travel Startdate");
		WebElement traveldate = driver.findElement(Startdate);
		waits(driver, Duration.ofSeconds(10), Startdate);
		Click(traveldate);
		log.debug("Entered Travel date:29/03/2023");
		WebElement travelend = driver.findElement(TravelEnd);
		waits(driver, Duration.ofSeconds(10), TravelEnd);
		Click(travelend);
		log.debug("Clicked on Travel Enddate");
		WebElement endmonth = driver.findElement(Endmonth);
		waits(driver, Duration.ofSeconds(10), Endmonth);
		Dropdown(endmonth, TravelEndMonth);
		log.debug("Entered TravelMonth:April");
		WebElement enddate = driver.findElement(Enddate);
		waits(driver, Duration.ofSeconds(10), Enddate);
		Click(enddate);
		log.debug("Entered Travel End Date:07/04/2024");
		WebElement next12 = driver.findElement(Next12);
		waits(driver, Duration.ofSeconds(10), Next12);
		Click(next12);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement next13 = driver.findElement(Next13);
		waits(driver, Duration.ofSeconds(10), Next13);
	    Click(next13);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement medicalneed = driver.findElement(Medicalneed);
		waits(driver, Duration.ofSeconds(10), Medicalneed);
		Sendkeys(medicalneed, "Breathing Issue");
		log.debug("Entered the Medical Issue");
		WebElement next14 = driver.findElement(Next14);
		waits(driver, Duration.ofSeconds(10), Next14);
		Click(next14);
		log.debug("Clicked on Next");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement next15 = driver.findElement(Next15);
		waits(driver, Duration.ofSeconds(10), Next15);
		Click(next15);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement next16 = driver.findElement(Next16);
		waits(driver, Duration.ofSeconds(10), Next16);
		Click(next16);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement next17 = driver.findElement(Next17);
		waits(driver, Duration.ofSeconds(10), Next17);
		Click(next17);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement docattached = driver.findElement(documentsattched);
		waits(driver, Duration.ofSeconds(10), documentsattched);
		Sendkeys(docattached, Documents);
		log.debug("Entered the Documents attched:Medical Reports");
		WebElement custom = driver.findElement(Customise);
		waits(driver, Duration.ofSeconds(10), Customise);
		Click(custom);
		log.debug("Clicked on Customise the template");
		WebElement k = driver.findElement(ok);
		waits(driver, Duration.ofSeconds(10), ok);
		Click(k);
		log.debug("Clicked on ok");
		WebElement save = driver.findElement(Save);
		waits(driver, Duration.ofSeconds(10), Save);
		Click(save);
		log.debug("Clicked on Save and Continue");
		WebElement email = driver.findElement(Email);
		waits(driver, Duration.ofSeconds(10), Email);
		Sendkeys(email, Emaill);
		log.debug("Entered Email");
		WebElement account = driver.findElement(Account);
		waits(driver, Duration.ofSeconds(10), Account);
		Click(account);
		log.debug("Clicked on i have an account");
		WebElement pswd = driver.findElement(Password);
		waits(driver, Duration.ofSeconds(10), Password);
		Sendkeys(pswd, PassWord);
		log.debug("Entered the Password");
		try {
			takescreenshot("WorldLegal_Login");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement login = driver.findElement(Login);
		waits(driver, Duration.ofSeconds(10), Login);
		Click(login);
		log.debug("Clicked on Login Button");
		WebElement edit = driver.findElement(Edit);
		waits(driver, Duration.ofSeconds(10), Edit);
		Click(edit);
		log.debug("Clicked on edit option");
		WebElement finish = driver.findElement(Finish);
		waits(driver, Duration.ofSeconds(10), Finish);
		Click(finish);
		log.debug("Clicked on Finish option");
			
}
}
