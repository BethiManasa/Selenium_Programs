package Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Tenants extends GenericMethods {
	WebDriver driver;
	public Tenants(WebDriver driver) {
		this.driver=driver;
	}
     By Menu = By.xpath("//div[@class='pageComponent hmenu__HamburgerMenuWrap']");
     By Login = By.xpath("//div[@class='P500 hmenu__loginRegister']//child::div[text()='LOGIN / REGISTER']");
     By ContinueEmail = By.xpath("//span[text()='Continue with Email/Username']");
     By Username = By.xpath("//input[@title='Email Id/Username']");
     By Continue_1 = By.xpath("//div[@class='emailUserNameLogin__submitBtn']");
     By Password = By.xpath("//input[@title='Password']");
     By Continue_2 = By.xpath("//span[text()='Continue']");
     By Tenants = By.xpath("(//div[@class='pageComponent theader__topmenu theader__Nav_item '])[1]/a");
     By rentBangalore = By.xpath("//a[text()='Property in Bangalore']");
   
//     public void Login_99Acres() {
//    	WebElement menu = driver.findElement(Menu);
//     	waits(driver, Duration.ofSeconds(20), Menu);
//     	Click(menu);
//     	log.debug("Clicked on Menu");
     	/*WebElement logn = driver.findElement(Login);
     	waits(driver, Duration.ofSeconds(20), Login);
     	Click(logn);
     	log.debug("Clicked on Login");
     	WebElement email = driver.findElement(ContinueEmail);
     	waits(driver, Duration.ofSeconds(10), ContinueEmail);
     	Click(email);
     	log.debug("Clicked on Continue with Email");
     	WebElement username = driver.findElement(Username);
     	waits(driver, Duration.ofSeconds(20), Username);
     	Sendkeys(username, "manasabasara@gmail.com");
     	log.debug("Entered Email ");
     	JavascriptExecutor js = (JavascriptExecutor)driver;
//     	WebElement cont1 = driver.findElement(Continue_1);
//     	waits(driver, Duration.ofSeconds(40), Continue_1);
//     	js.executeScript("arguments[0].click();", cont1);
     	try {
     	    WebElement cont1 = driver.findElement(Continue_1);
     	    waits(driver, Duration.ofSeconds(40), Continue_1);
     	    js.executeScript("arguments[0].click();", cont1);
     	    log.debug("Clicked on Continue button");
     	} catch (Exception e) {
     	    log.error("Error clicking Continue button: " + e.getMessage());
     	    e.printStackTrace();
     	}
//     	WebElement password = driver.findElement(Password);
//     	waits(driver, Duration.ofSeconds(20), Password);
//     	Sendkeys(password, "Man@cx");
//     	log.debug("Entered Password");
//     	WebElement cont2 = driver.findElement(Continue_2);
//     	waits(driver, Duration.ofSeconds(20),Continue_2 );
//     	Click(cont2);
//     	log.debug("Clicked on Continue");
     /*	try {
     	    WebElement password = driver.findElement(Password);
     	    waits(driver, Duration.ofSeconds(20), Password);
     	    Sendkeys(password, "Man@cx");
     	    log.debug("Entered Password");
     	    
     	    WebElement cont2 = driver.findElement(Continue_2);
     	    waits(driver, Duration.ofSeconds(20), Continue_2);
     	    Click(cont2);
     	    log.debug("Clicked on Continue");
     	} catch (Exception e) {
     	    log.error("Error entering password or clicking Continue: " + e.getMessage());
     	    e.printStackTrace();
     	}*/
     	
     	
        public void Tenants_99Acres() {
//       	WebElement menu = driver.findElement(Menu);
//        	waits(driver, Duration.ofSeconds(20), Menu);
//        	Click(menu);
//        	log.debug("Clicked on Menu");
        	JavascriptExecutor js = (JavascriptExecutor)driver;
        	WebElement tenant = driver.findElement(Tenants);
        	waits(driver, Duration.ofSeconds(20), Tenants);
        	Click(tenant);
        	log.debug("Clicked on Tenant");
        	WebElement rent = driver.findElement(rentBangalore);
        	js.executeScript("arguments[0].click();", rent);
        	

        	
     	
     }
     
}
