package Pages;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Abhibus extends GenericMethods{
	WebDriver driver;
	public Abhibus(WebDriver driver) {
		this.driver = driver;
	}
	//By Bus = By.xpath("//a[@id='bus-link']//child::span[2]");
    By FromStation = By.xpath("//input[@placeholder='From Station']");
    By Hyd = By.xpath("//div[@class='container auto-complete-drop-down ']//ul//li[1]");
    By ToStation = By.xpath("//input[@placeholder='To Station']");
    By Bang = By.xpath("//div[@class='container auto-complete-drop-down ']//child::li[@data-id='Bangalore']");
    By SelectDate = By.xpath("//input[@placeholder='Onward Journey Date']");
    //    By Date = By.xpath("//input[@value='23/02/2024']");
    By Today = By.xpath("//button[text()='Today']");
    // By Search = By.xpath("//div[@id='search-button']//child::button");
    By Ac = By.xpath("(//a[@class='btn  outlined tertiary sm inactive button'])[1]");
    By Sleeper = By.xpath("(//a[@class='btn  outlined tertiary sm inactive button'])[3]");
    By DepartureTime = By.xpath("//div[@id='seat-filter-departure-list']//a[3]/span[2]");
    By Boarding = By.xpath("//div[text()='Boarding Point']");
    By Uppal = By.xpath("//div[@id='list-filter-option-container']/div[2]//child::div[180]/label");
    By Dropping = By.xpath("//div[text()='Dropping Point']");
    By multiplex = By.xpath("//div[@id='list-filter-option-container']/div[2]//child::div[307]/label");
    By Text = By.xpath("//div[@id='service-operator-agent-name-1893247162']/h5");
	By Showseat = By.xpath("//button[text()='Show Seats']");
	
    public void Searching_Bus() {
    	WebElement from = driver.findElement(FromStation);
    	waits(driver, Duration.ofSeconds(20),FromStation );
    	Click(from);
    	log.debug("Clicked on FromStation");
    	WebElement hyd = driver.findElement(Hyd);
    	waits(driver, Duration.ofSeconds(20),Hyd );
    	Click(hyd);
    	log.debug("'Hyderabad' is Selected");
    	WebElement To = driver.findElement(ToStation);
    	waits(driver, Duration.ofSeconds(20),ToStation );
    	Sendkeys(To, "Bangalore");
    	log.debug("Clicked on ToStation");
    	WebElement bang = driver.findElement(Bang);
    	waits(driver, Duration.ofSeconds(20),Bang );
    	Click(bang);
    	log.debug("'Bangalore' is Selected");
    	WebElement selectdate = driver.findElement(SelectDate);
    	waits(driver, Duration.ofSeconds(20),SelectDate );
    	Click(selectdate);
    	log.debug("Travel date is Selected");
//    	WebElement date = driver.findElement(Date);
//    	waits(driver, Duration.ofSeconds(20),Date );
//    	Click(date);
    	WebElement today = driver.findElement(Today);
  	    waits(driver, Duration.ofSeconds(20), Today);
   	    Click(today);
//    	WebElement searching = driver.findElement(Search);
//    	Click(searching); 	
    }
       public void Filters() {   
        WebElement ac = driver.findElement(Ac);
       	waits(driver, Duration.ofSeconds(20),Ac );
       	Click(ac);
       	log.debug("Bus Type Ac is Selected");
       	WebElement seat = driver.findElement(Sleeper);
       	waits(driver, Duration.ofSeconds(20),Sleeper );
       	Click(seat);
    	log.debug("Bus Type Sleeper is Selected");
       	WebElement time = driver.findElement(DepartureTime);
       	waits(driver, Duration.ofSeconds(20),DepartureTime );
       	Click(time);
    	log.debug("The selected departure Time is 5PM-11PM");
       	WebElement boarding = driver.findElement(Boarding);
       	waits(driver, Duration.ofSeconds(20),Boarding );
       	Click(boarding);
    	log.debug("Clicked on Boarding Point");
       	WebElement uppal = driver.findElement(Uppal);
       	waits(driver, Duration.ofSeconds(20),Uppal );
       	Click(uppal);
       	log.debug("The Boarding Point Selected is:Uppal");
       	WebElement dropping = driver.findElement(Dropping);
       	waits(driver, Duration.ofSeconds(20),Dropping );
       	Click(dropping);
       	log.debug("Clicked on Dropping Point");
    	WebElement multi = driver.findElement(multiplex);
       	waits(driver, Duration.ofSeconds(20),multiplex );
       	Click(multi);
       	log.debug("The selected Dropping Point is:Maratahalli Multiplex");
       	WebElement text = driver.findElement(Text);
       	waits(driver, Duration.ofSeconds(20),Text );
        String a=  getText(text);
        log.debug("The Displayed Bus after applying Filters:Mahi Trans Solutions");
        System.out.println("The Selected bus is:"+a);
        WebElement show = driver.findElement(Showseat);
        waits(driver, Duration.ofSeconds(20),Showseat );
        Click(show);
        log.debug("Clicked on ShowSeats");
        try {
			takescreenshot("BusJourney");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        log.debug("Screenshot of BusJourney is Captured");
       	
	} 
}
