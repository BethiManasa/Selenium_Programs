package Pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Iterator;
import java.util.Set;

import org.testng.annotations.DataProvider;

/*public class ex {
	test = report.startTest("CodeBeautify_Test");
	test.log(LogStatus.PASS, "CodeBeautify_Test is passed");
	report.endTest(test);
	report.flush();
	@DataProvider
	public Object[][] getData() {
	    String sheetname = "CodeBeautify_Login";
	    int rows = excel.getRowCount(sheetname);
	    int cols = excel.getColumnCount(sheetname);
	    
	    // Ensure that the data array size matches the number of rows
	    Object[][] data = new Object[rows - 1][cols];
	    
	    for (int rowNum = 2; rowNum <= rows; rowNum++) {
	        for (int colNum = 0; colNum < cols; colNum++) {
	            data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
	        }
	    }
	    
	    return data;
	     String parent_Win = driver.getWindowHandle();            
		Set<String> s = driver.getWindowHandles();
		
		Iterator<String> i = s.iterator();
		while(i.hasNext()) {
			String Child_Win = i.next();
			if(!(parent_Win.equals(Child_Win))) {
				driver.switchTo().window(Child_Win);
			}
		}
		String title = driver.getTitle();
		System.out.println(title);
		driver.switchTo().window(parent_Win);
	}
	 Robot r = new Robot();
		   StringSelection path=new StringSelection("\"C:\\Users\\BEMANASA\\Downloads\\jsonformatter.txt\"");
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(path, null);
          r.keyPress(KeyEvent.VK_CONTROL);
	       r.keyPress(KeyEvent.VK_V);
	       r.keyRelease(KeyEvent.VK_V);
	       r.keyRelease(KeyEvent.VK_CONTROL);
	       r.keyPress(KeyEvent.VK_ENTER);
	       r.keyRelease(KeyEvent.VK_ENTER);
    } */


