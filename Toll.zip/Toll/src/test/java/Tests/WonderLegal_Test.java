package Tests;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import Pages.WonderLegal;

public class WonderLegal_Test extends Driver {

	@Test
	public void LeaverequestLetter() {
		test = report.startTest("WonderLegal_Test");
		test.log(LogStatus.PASS, "WonderLegal_Test is passed");
		WonderLegal wl = new WonderLegal(driver);
		wl.LeaveRequestLetter();
		report.endTest(test);
		report.flush();
	}
}
