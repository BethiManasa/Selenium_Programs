package Tests;

import org.testng.annotations.Test;

import Pages.MyBookings;

public class MyBookings_Test extends Driver {
	@Test
	public void NoBroker_Bookings() {
		MyBookings mb = new MyBookings(driver) ;
			mb.NoBroker_Login();
			mb.Bookings();
		
	}
	
	
}
