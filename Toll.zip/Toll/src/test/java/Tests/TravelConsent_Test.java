package Tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.TravelConsent;

public class TravelConsent_Test extends Driver {

	@Test(dataProvider="getData")
	public void LeaverequestLetter(String TravellingWith,String Parentname,String ParentAddress,String Parentcontactnum,String ParentEmail,String FirstChildName,String FirstChildGender,String Monthh,
			String ElderPlace,String ElderPassport,String SecondChildName,String Monthhh,String SecondPlace,String SecondPassport,String Destination,String TravelEndMonth,String Documents,
			String Emaill,String PassWord) {
		test = report.startTest("TravelConsent_Test");
		test.log(LogStatus.PASS, "TravelConsent_Test is passed");
		TravelConsent tc = new TravelConsent(driver);
		tc.TraveConsentForm(TravellingWith,Parentname,ParentAddress,Parentcontactnum,ParentEmail,FirstChildName,FirstChildGender,Monthh,ElderPlace,ElderPassport,SecondChildName,Monthhh,
				SecondPlace,SecondPassport,Destination,TravelEndMonth,Documents,Emaill,PassWord);
		report.endTest(test);
		report.flush();		
}
	@DataProvider
	public Object[][] getData() {
	    String sheetname = "WonderLegal";
	    int rows = excel.getRowCount(sheetname);
	    int cols = excel.getColumnCount(sheetname);
	    
	    // Ensure that the data array size matches the number of rows
	    Object[][] data = new Object[rows - 1][cols];
	    
	    for (int rowNum = 2; rowNum <= rows; rowNum++) {
	        for (int colNum = 0; colNum < cols; colNum++) {
	            data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
	        }
	    }
	    
	    return data;
	}
}
