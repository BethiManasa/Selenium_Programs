package Tests;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.Painting_Cleaning;

public class Painting_Cleaning_Test extends Driver {
	
	
	
	@Test
	public void NoBroker_paintingCleaning() {
		
		test = report.startTest("Painting_Cleaning_Test");
			test.log(LogStatus.PASS, "Painting_Cleaning_Test is pass");
			
		Painting_Cleaning pc = new Painting_Cleaning(driver);
		pc.NoBroker_Login();
		pc.Painting_Cleaning_Facilities();
		report.endTest(test);
		report.flush();

}
}
