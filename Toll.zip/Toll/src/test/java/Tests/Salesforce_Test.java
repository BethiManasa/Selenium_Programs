package Tests;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;

import Pages.Salesforce;
public class Salesforce_Test extends Driver {
	@Test
	public void Login_Salesforce() {
		test = report.startTest("Salesforce_Test");
		test.log(LogStatus.PASS, "Salesforce_Test is pass");
		Salesforce s = new Salesforce(driver);
		s.Salesforce_Login();
        report.endTest(test);
		report.flush();
	}
	
}
