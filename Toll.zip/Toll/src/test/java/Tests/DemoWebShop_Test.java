package Tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.DemoWebShop;

public class DemoWebShop_Test extends Driver{
@Test(dataProvider="getData")
public void WebShop(String Email,String Password,String Sorting,String Viewas,String quantity,String SelectCountry,String PostalCode) {
	test = report.startTest("DemoWebShop_Test");
	test.log(LogStatus.PASS, "DemoWebShop_Test is passed");
	DemoWebShop d = new DemoWebShop(driver);
	d.WebShop_Login(Email, Password);
	d.Filter_Operations(Sorting,Viewas);
	d.AddtoCart(quantity,SelectCountry,PostalCode);
	d.Checkout_Process();
	report.endTest(test);
	report.flush();
}

@DataProvider
public Object[][] getData() {
    String sheetname = "WebShop";
    int rows = excel.getRowCount(sheetname);
    int cols = excel.getColumnCount(sheetname);
    
    // Ensure that the data array size matches the number of rows
    Object[][] data = new Object[rows - 1][cols];
    
    for (int rowNum = 2; rowNum <= rows; rowNum++) {
        for (int colNum = 0; colNum < cols; colNum++) {
            data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
        }
    }
    
    return data;
}
}
