package Tests;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import Utilities.ExcelReader;
import Utilities.ExtentManager;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.log4j.Logger;
public class Driver {
	public static WebDriver driver;
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static ExtentReports report = ExtentManager.getInstance();
	public static ExtentTest test;
	public static ExcelReader excel= new ExcelReader("C:\\Users\\BEMANASA\\eclipse-workspace\\Toll\\src\\test\\resources\\Excel\\Shoppre.xlsx");
	 String filePath = "C:\\Users\\BEMANASA\\eclipse-workspace\\Toll\\src\\test\\resources\\Excel\\DataWriter.xlsx";
	 
	@BeforeSuite
	public void browserSetup() {
   WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(); 
		driver.get("https://magento.softwaretestingboard.com/");
		 	driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
			driver.manage().window().maximize();
			log.debug("Driver is initialised");
			
		 }
	
	//@AfterSuite
			public void CloseBrowser() {
				if(driver!=null) {
					driver.quit();
					log.debug("Driver is Closed");
					
					
				}
			}

}
