package Tests;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import Pages.OyoDelhi;

public class OyoDelhi_Test extends Driver{
	@Test
	public void Oyo_Bookings() {
		test = report.startTest("OyoDelhi_Test");
		test.log(LogStatus.PASS, "OyoDelhi_Test is passed");
		OyoDelhi od = new OyoDelhi(driver);
		od.Selecting_Oyorooms_Delhi();
		report.endTest(test);
		report.flush();
}
}
