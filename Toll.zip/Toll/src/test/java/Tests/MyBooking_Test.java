package Tests;

import org.testng.annotations.Test;

import Pages.MyBooking;

public class MyBooking_Test extends Driver {
	@Test
	public void NoBroker_Bookings() {
		MyBooking mb = new MyBooking(driver) ;
			mb.NoBroker_Login();
			mb.Bookinggg();
			
		
	}
}
