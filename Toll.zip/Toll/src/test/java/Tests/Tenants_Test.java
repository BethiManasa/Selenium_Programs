package Tests;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.Tenants;

public class Tenants_Test extends Driver {
	@Test
	public void Tenants_99Acres() {
		test = report.startTest("Salesforce_Test");
		test.log(LogStatus.PASS, "Salesforce_Test is pass");
		Tenants t = new Tenants(driver);
		t.Tenants_99Acres();
        report.endTest(test);
		report.flush();
	}

}
