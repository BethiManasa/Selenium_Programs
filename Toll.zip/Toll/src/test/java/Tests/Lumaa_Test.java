package Tests;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.Lumaa;

public class Lumaa_Test extends Driver {
	@Test
	public void Lumaa_Login() {
		test = report.startTest("Lumaa_Test");
		test.log(LogStatus.PASS, "Lumaa_Test is passed");
		Lumaa l = new Lumaa(driver);
		l.Luma_Login();
		l.Exploring_MensBottomsPants();
		l.MensBottoms_Shorts();
		report.endTest(test);
		report.flush();
	}
	
}
