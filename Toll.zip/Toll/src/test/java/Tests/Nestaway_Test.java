package Tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.Nestaway;

public class Nestaway_Test extends Driver{
	@Test(dataProvider="getData")
public void Nestaway_Exploring(String Email,String Password,String Locality) {
	test = report.startTest("Nestaway_Test");
	test.log(LogStatus.PASS, "Nestaway_Test is passed");
	Nestaway na = new Nestaway(driver);
	na.Nestaway_Login(Email, Password);
	na.Exploring_Houses(Locality);
	report.endTest(test);
	report.flush();
	
	
}
@DataProvider
public Object[][] getData() {
    String sheetname = "NestawayLogin";
    int rows = excel.getRowCount(sheetname);
    int cols = excel.getColumnCount(sheetname);
    
    // Ensure that the data array size matches the number of rows
    Object[][] data = new Object[rows - 1][cols];
    
    for (int rowNum = 2; rowNum <= rows; rowNum++) {
        for (int colNum = 0; colNum < cols; colNum++) {
            data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
        }
    }
    
    return data;
}

}
