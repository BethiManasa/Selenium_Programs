package Tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.Shoppre;

public class Shoppre_Test extends Driver{
	
	@Test(dataProvider="getData")
	public void Ajio_Shoppre(String FirstName,String LastName,String Email,String Password) {
		test = report.startTest("Shoppre_Test");
		test.log(LogStatus.PASS, "Shoppre_Test is pass");
		Shoppre s = new Shoppre(driver);
        s.SignUp(FirstName, LastName, Email, Password);
        s.Stores();
        report.endTest(test);
		report.flush();
	}
	@DataProvider
	public Object[][] getData() {
	    String sheetname = "SignUp";
	    int rows = excel.getRowCount(sheetname);
	    int cols = excel.getColumnCount(sheetname);
	    
	    // Ensure that the data array size matches the number of rows
	    Object[][] data = new Object[rows - 1][cols];
	    
	    for (int rowNum = 2; rowNum <= rows; rowNum++) {
	        for (int colNum = 0; colNum < cols; colNum++) {
	            data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
	        }
	    }
	    
	    return data;
	}

}
