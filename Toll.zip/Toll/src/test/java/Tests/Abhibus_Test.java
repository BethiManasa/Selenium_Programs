package Tests;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.Abhibus;
import Pages.Profile;

public class Abhibus_Test extends Driver {
	@Test
	public void Abhibus_Bus() {
		test = report.startTest("Abhibus_Test");
		test.log(LogStatus.PASS, "Abhibus_Test is passed");
		Abhibus b = new Abhibus(driver);
		b.Searching_Bus();
		b.Filters();
		report.endTest(test);
		report.flush();
	}

}
