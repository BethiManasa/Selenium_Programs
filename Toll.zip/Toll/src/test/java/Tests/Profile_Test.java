package Tests;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.Profile;
public class Profile_Test extends Driver {
	@Test
	public void Next_Profile() {
		test = report.startTest("Profile_Test");
		test.log(LogStatus.PASS, "Profile_Test is passed");
		Profile p = new Profile(driver);
		p.Profile_Exploring();
		report.endTest(test);
		report.flush();
	}
		

}
