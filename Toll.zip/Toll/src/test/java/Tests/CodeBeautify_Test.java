package Tests;

import java.awt.AWTException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Pages.CodeBeautify;

public class CodeBeautify_Test extends Driver{
	@Test(dataProvider="getData")
	public void CodeBeautifier(String Email,String Password,String Searchtext,String Inputtext,String StringSpecialCharacters,String StringNumbers) throws AWTException {
		test = report.startTest("CodeBeautify_Test");
		test.log(LogStatus.PASS, "CodeBeautify_Test is passed");
		CodeBeautify cb = new CodeBeautify(driver);
		cb.CodeBeautifier_Login(Email,Password );
		cb.Md2_Hash_Generator(Searchtext,Inputtext,StringSpecialCharacters,StringNumbers);
		cb.JSON_Formatter();
		cb.JSON_Beautifier();
		report.endTest(test);
		report.flush();
		
	}
	@DataProvider
	public Object[][] getData() {
	    String sheetname = "CodeBeautify_Login";
	    int rows = excel.getRowCount(sheetname);
	    int cols = excel.getColumnCount(sheetname);
	    
	    // Ensure that the data array size matches the number of rows
	    Object[][] data = new Object[rows - 1][cols];
	    
	    for (int rowNum = 2; rowNum <= rows; rowNum++) {
	        for (int colNum = 0; colNum < cols; colNum++) {
	            data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
	        }
	    }
	    
	    return data;
	}
    
}
