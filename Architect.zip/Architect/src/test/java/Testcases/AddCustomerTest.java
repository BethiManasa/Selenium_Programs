package Testcases;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Base.TestBase;
public class AddCustomerTest extends TestBase{
	@Test(dataProvider="getData")
	public void AddCustomer(String FirstName,String LastName,String PostalCode,String alertText) {
		driver.findElement(By.xpath(OR.getProperty("Addcustomer"))).click();
		driver.findElement(By.xpath(OR.getProperty("firstname"))).sendKeys(FirstName);
		driver.findElement(By.xpath(OR.getProperty("lastname"))).sendKeys(LastName);
		driver.findElement(By.xpath(OR.getProperty("postcode"))).sendKeys(PostalCode);
		driver.findElement(By.xpath(OR.getProperty("addbtn"))).click();
		Alert ale = wait.until(ExpectedConditions.alertIsPresent());
		Assert.assertTrue(ale.getText().contains(alertText));
		ale.accept();
		
	
	}
	@DataProvider
	public Object[][] getData(){
		String sheetname = "AddCust";
	    int rows = excel.getRowCount(sheetname);
	    int cols = excel.getColumnCount(sheetname);
	    
	    // Ensure that the data array size matches the number of rows
	    Object[][] data = new Object[rows - 1][cols];
	    
	    for (int rowNum = 2; rowNum <= rows; rowNum++) {
	        for (int colNum = 0; colNum < cols; colNum++) {
	        	//data[0][0]

	        	data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
	        }
	    }
	    
	    return data;	
	}

}
