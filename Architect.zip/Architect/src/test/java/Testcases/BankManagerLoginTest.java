package Testcases;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.openqa.selenium.By;


import Base.TestBase;

public class BankManagerLoginTest extends TestBase {
	@Test
	public void BankManagerLogin() {
		
		driver.findElement(By.xpath(OR.getProperty("bankmanagerlogn"))).click();
        log.debug("Clicked on BankmangerLogin");
 //Assertions: finding the Element is present aftr CLicking on BankMngerLogin
        Assert.assertTrue(isElementPresent(By.xpath(OR.getProperty("Addcustomer"))),"Login not SUccesful");
 //testng Reports
//        Reporter.log("Clicked on BankManagerLogin");
//        Reporter.log("a<href=\"C:\\Users\\BEMANASA\\Pictures\\P_Aadhar.jpg\">Screenshot</a>");
   //For capturing SCreenshot.
      // Assert.fail("login not Successful");
        
	}

}
