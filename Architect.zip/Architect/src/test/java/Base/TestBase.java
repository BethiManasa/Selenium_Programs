package Base;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import Utilities.ExcelReader;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {
	
//Initialisation of webdriver,excel ,reports,logs ,Properties .........
	public static ChromeDriver driver;
	public static Properties config = new Properties();
	public static Properties  OR = new Properties();
	public static FileInputStream fis;
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static ExcelReader excel = new ExcelReader("C:\\Users\\BEMANASA\\eclipse-workspace\\Architect\\src\\test\\resources\\Excel\\SeleniumArchitect_xyzbank.xlsx");
	public static WebDriverWait wait;
	
	@BeforeSuite
    public void Start() throws IOException {
        // Check if the driver instance is null before initializing
        if (driver == null) {
            // loading files: path
            FileInputStream fis = new FileInputStream(
                System.getProperty("user.dir") + "\\src\\test\\resources\\Properties\\Config.properties");
            config.load(fis);
            log.debug("Config file Loaded");
            fis = new FileInputStream(
                System.getProperty("user.dir") + "\\src\\test\\resources\\Properties\\OR.properties");
            OR.load(fis);
            log.debug("OR file loaded");
            // Calling Properties
            WebDriverManager.chromedriver().setup();
            // Instantiate ChromeDriver
            driver = new ChromeDriver();
            log.debug("Chrome Launched");
            driver.get(config.getProperty("testsiteurl"));
            log.debug("Navigated to :"+config.getProperty("testsiteurl"));
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);	
            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}
	}
	public boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		}
		catch(NoSuchElementException e){
			return false;
		}
	}
	
//	@AfterSuite
	public void teardown() {
		if(driver!=null) {
		driver.quit();
		
	}
		config.getProperty("Test Execution completed");
}
}

