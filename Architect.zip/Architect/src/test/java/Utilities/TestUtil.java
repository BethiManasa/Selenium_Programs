package Utilities;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import Base.TestBase;
public class TestUtil extends TestBase{
	public static String screenshotpath;
	public static String ScreenshotName;
	public static void captureScreenshot() throws IOException {
	//interface
   File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
   ScreenshotName = "P_Aadhar.jpg";
   FileUtils.copyFile(srcFile,new File(System.getProperty("C:\\Users\\BEMANASA\\eclipse-workspace\\Architect\\test-output\\html"+ScreenshotName)));
		
	}

}
