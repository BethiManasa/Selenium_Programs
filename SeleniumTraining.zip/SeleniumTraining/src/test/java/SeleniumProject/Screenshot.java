package SeleniumProject;


import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;


public class Screenshot {

	   static WebDriver driver;
	   public static void takescreenshot(String fileName) throws IOException {
		File file =   ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("C://Users//BEMANASA//eclipse-workspace//SeleniumTraining//Screenshot//" +fileName+ ".jpg"));
		} 

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		driver = new EdgeDriver();
		String actUrl ="https://stock.adobe.com/in/search?k=monkey&asset_id=1974128";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");                                                                                                                                                                                                                                                                                                                                                 
		
		driver.get("https://stock.adobe.com/in/search?k=monkey&asset_id=1974128");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String expUrl = driver.getCurrentUrl();
		//Assert.assertEquals(expUrl, actUrl);
		System.out.println("Validation Successful");
		
		takescreenshot("Image");
	
		
	
	}

}
