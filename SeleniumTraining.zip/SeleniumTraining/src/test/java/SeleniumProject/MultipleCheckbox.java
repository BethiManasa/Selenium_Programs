package SeleniumProject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;

public class MultipleCheckbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver;
		String actUrl ="https://www.sparkstone.co.nz/sampleapp/101/app.php";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");
		driver = new EdgeDriver();
		driver.get("https://www.sparkstone.co.nz/sampleapp/101/app.php");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String expUrl = driver.getCurrentUrl();
		Assert.assertEquals(expUrl, actUrl);
		System.out.println("Validation Successful");
		driver.findElement(By.id("enterinsurantdata")).click();
		List<WebElement> list  = driver.findElements(By.xpath("(//p[@class='group'])[position()=3]/label"));
	//foreach
		for (WebElement Element : list) {
			if(!(Element.isSelected())) {
				Element.click();
			}
			
		}
		

	}

}
