package SeleniumProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;

public class Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver;
		String actUrl ="https://jpetstore.aspectran.com/account/signonForm?referer=%2Forder%2FviewOrder";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");                                                                                                                                                                                                                                                                                                                                                 
		driver = new EdgeDriver();
		driver.get("https://jpetstore.aspectran.com/account/signonForm?referer=%2Forder%2FviewOrder");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String expUrl = driver.getCurrentUrl();
		Assert.assertEquals(expUrl, actUrl);
		System.out.println("Validation Successful");
	

	}

}
