package SeleniumProject;

import java.util.Iterator;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;

public class WindowsHandle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver;
		String actUrl ="https://demo.automationtesting.in/Windows.html";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");
		driver = new EdgeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String expUrl = driver.getCurrentUrl();
		Assert.assertEquals(expUrl, actUrl);
		System.out.println("Validation Successful");
		driver.findElement(By.partialLinkText("Open New Seperate Windows")).click();
		driver.findElement(By.xpath("//button[text()='click']")).click();
		
		 String parent_Win = driver.getWindowHandle();            
		Set<String> s = driver.getWindowHandles();
		
		Iterator<String> i = s.iterator();
		while(i.hasNext()) {
			String Child_Win = i.next();
			if(!(parent_Win.equals(Child_Win))) {
				driver.switchTo().window(Child_Win);
			}
		}
		String title = driver.getTitle();
		System.out.println(title);
		driver.switchTo().window(parent_Win);
	}

}
