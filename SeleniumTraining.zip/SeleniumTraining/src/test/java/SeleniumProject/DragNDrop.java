package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class DragNDrop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver;
		String actUrl ="https://www.lambdatest.com/selenium-playground/drag-and-drop-demo";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");                                                                                                                                                                                                                                                                                                                                                 
		driver = new EdgeDriver();
		driver.get("https://www.lambdatest.com/selenium-playground/drag-and-drop-demo");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String expUrl = driver.getCurrentUrl();
		Assert.assertEquals(expUrl, actUrl);
		System.out.println("Validation Successful");
		WebElement s1 = driver.findElement(By.xpath("//span[text()='Draggable 1']"));   //drag-1
		WebElement s2 = driver.findElement(By.xpath("//span[text()='Draggable 2']"));   //drag-2
  
	    WebElement des = driver.findElement(By.id("mydropzone"));                       //destination
	    Actions act = new Actions(driver); 
		act.dragAndDrop(s1,des).perform();
		act.dragAndDrop(s2,des).perform();
		WebElement a = driver.findElement(By.id("droppedlist"));
		String s = a.getText();
		System.out.println(s);
	
//Drag Drop(Demo-2)
		
		WebElement source = driver.findElement(By.id("draggable"));
		WebElement Destination = driver.findElement(By.id("droppable"));
		Actions action = new Actions(driver);
		action.dragAndDropBy(source, 150, 50).build().perform();
		
	}

}
