package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;


public class Basics {
      
	public static void main(String[] args) {
		WebDriver driver;
		String actUrl ="https://soliterata.com/testing-tool-wep-page/elements/check-box/";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");
		driver = new EdgeDriver();
		driver.get("https://soliterata.com/testing-tool-wep-page/elements/check-box/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String expUrl = driver.getCurrentUrl();
		Assert.assertEquals(expUrl, actUrl);
		System.out.println("Validation Successful");
		//driver.findElement(By.xpath("//span[text()='Accept']")).click();
		driver.findElement(By.linkText("Accept")).click();
		WebElement ele = driver.findElement(By.id("myCheck"));
		ele.click();
		if(ele.isSelected()) {
			System.out.println("Checkbox is Selected");
		}
		driver.findElement(By.xpath("//button[@onclick='myFunction()']")).click();
		String text = driver.findElement(By.id("demo")).getText();
		System.out.println(text);
		
	}
       
}
