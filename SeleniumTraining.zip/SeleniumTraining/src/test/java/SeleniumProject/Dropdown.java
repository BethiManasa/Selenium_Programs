package SeleniumProject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Dropdown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver;
		String actUrl ="https://www.globalsqa.com/demo-site/select-dropdown-menu/";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");                                                                                                                                                                                                                                                                                                                                                 
		driver = new EdgeDriver();
		driver.get("https://www.globalsqa.com/demo-site/select-dropdown-menu/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String expUrl = driver.getCurrentUrl();
		Assert.assertEquals(expUrl, actUrl);
		System.out.println("Validation Successful");
		Select Dropdown = new Select(driver.findElement(By.xpath("//div[@class='single_tab_div']/p/select")));
		/*Dropdown.selectByIndex(1);
		Thread.sleep(5000);
		Dropdown.selectByValue("ALB");
		Thread.sleep(5000);
		Dropdown.selectByVisibleText("American Samoa");   */
	
		List<WebElement> options = Dropdown.getOptions();
		for (WebElement Element : options) {
			System.out.println(Element.getText());
			System.out.println("Size is :" +options.size());
			if(Element.getText().equals("Argentina")) {
				Element.click();
				break;
			}
			
		}

	}

}
