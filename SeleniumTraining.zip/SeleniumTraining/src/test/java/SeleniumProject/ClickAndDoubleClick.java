package SeleniumProject;


import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class ClickAndDoubleClick {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		WebDriver driver;
		String actUrl ="https://soliterata.com/testing-tool-wep-page/elements/buttons/";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");                                                                                                                                                                                                                                                                                                                                                 
		driver = new EdgeDriver();
		driver.get("https://soliterata.com/testing-tool-wep-page/elements/buttons/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String expUrl = driver.getCurrentUrl();
		Assert.assertEquals(expUrl, actUrl);
		System.out.println("Validation Successful");
		driver.findElement(By.linkText("Accept")).click();
		driver.findElement(By.xpath("//span[text()='Buttons']")).click();
	//whenever the Element not clickabale Error occurs with coordinate point - Perform Scroll action.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5000));        //Implicit wait
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,250)");
		driver.findElement(By.xpath("//button[text()='Click me']")).click();
	//Printing Text
		WebElement ele = driver.findElement(By.id("singleClick"));
		System.out.println(ele.getText());
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5000));   //explicit wait
				wait.until(ExpectedConditions.elementToBeClickable(ele));	
	//Double Click
		WebElement element = driver.findElement(By.xpath("//button[@ondblclick='myFunction2()']"));
		Actions action = new Actions(driver);
		//WebElement element = driver.findElement(By.xpath("//button[@ondblclick='myFunction2()']"));
		action.doubleClick(element).perform();
		WebElement Ele = driver.findElement(By.id("demo"));
		System.out.println(Ele.getText());
		
		}

}

