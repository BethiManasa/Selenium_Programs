package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class Sendkeys {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;
		String actUrl ="https://www.google.com/";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");                                                                                                                                                                                                                                                                                                                                                 
		driver = new EdgeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement a= driver.findElement(By.id("APjFqb"));
		a.sendKeys("manasa");
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].setAttribute('style','background:red')", a);
		//driver.quit();
	}

}
