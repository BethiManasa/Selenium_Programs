package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class Slider {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver;
		String actUrl ="https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");                                                                                                                                                                                                                                                                                                                                                 
		driver = new EdgeDriver();
		driver.get("https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String expUrl = driver.getCurrentUrl();
		Assert.assertEquals(expUrl, actUrl);
		System.out.println("Validation Successful");
		Actions act=new Actions(driver);
		WebElement max_slider=driver.findElement(By.xpath("//div[@id=\"slider-range\"]/span[2]"));
		System.out.println("location before sliding:" +max_slider.getLocation());
		act.dragAndDropBy(max_slider, -110, 249).perform();
		System.out.println("location after sliding:" +max_slider.getLocation());

	}

}
