package SeleniumProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Searching_Vehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("WebDriver.Chrome.driver", "C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
       WebDriver driver = new ChromeDriver();
       driver.get("https://www.cardekho.com/");
       
	}

}
