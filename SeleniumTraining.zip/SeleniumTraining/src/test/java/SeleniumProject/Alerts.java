package SeleniumProject;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import com.beust.ah.A;

public class Alerts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver;
		String actUrl ="https://the-internet.herokuapp.com/javascript_alerts";
		System.setProperty("WebDriver.Edge.driver","C://Users//BEMANASA//Downloads//edgedriver_win64//msedgedriver.exe");
		//System.setProperty("WebDriver.edge.driver", ("user dir")+ "msedgedriver.exe");
		driver = new EdgeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		 driver.findElement(By.xpath("//button[text()='Click for JS Alert']")).click();
         Alert alert  = driver.switchTo().alert();
         alert.accept();
         WebElement a = driver.findElement(By.id("result"));
          String s= a.getText();
         System.out.println(s);
         driver.findElement(By.xpath("//button[@onclick='jsConfirm()']")).click();
         Alert ale = driver.switchTo().alert();
         ale.dismiss();
         WebElement b = driver.findElement(By.id("result"));
         String m = a.getText();
         System.out.println(m);
       
          driver.findElement(By.xpath("//button[@onclick='jsPrompt()']")).click();
          Alert alem = driver.switchTo().alert();
          alem.sendKeys("Manasa");
          alem.accept();
          WebElement c = driver.findElement(By.id("result"));
          String n = c.getText();
          System.out.println(n);    
         
	}

}
