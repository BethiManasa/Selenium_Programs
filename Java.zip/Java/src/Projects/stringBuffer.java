package Projects;

public class stringBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		/*StringBuffer  sb = new StringBuffer("Manasa");
		// sb = new StringBuffer("Manasa Bethi");
		 sb.append(" Bethi");
		 System.out.println(sb);
		 
		 sb.insert(7,"Sravani ");
		 System.out.println(sb);
		 
		 sb.deleteCharAt(2);
		 System.out.println(sb);
		 
		 sb.reverse();
		 System.out.println(sb);
		 
		 sb.delete(1, 4);
		 System.out.println(sb);   */
	
		StringBuffer sa = new StringBuffer();
		//sa.capacity();
		System.out.println(sa.capacity());
		/*sa.append("Manasa");
		System.out.println(sa.capacity());
		sa.append("Learning java concepts");
		System.out.println(sa.capacity());
		sa.append("in Training"); 
		System.out.println(sa.capacity()); */
		StringBuffer sc = new StringBuffer("Manasa");
		sa.capacity();
		System.out.println(sc.capacity());
		
	}

}
