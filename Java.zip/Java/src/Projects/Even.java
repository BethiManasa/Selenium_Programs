package Projects;

public class Even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int i = 8;
          if(i%2==0) {
        	  System.out.println("i is Even" );
        	  
          }
          else 
    		  System.out.println("odd");
          
          for(i=1;i<=10;i++) {
        	  if(i%2==0) {
        		  
        		 System.out.println(i); 
        		 
        	  }
        	 
          }
	}

}
