package Projects;

public class SingleArray { 
	  public static void main(String[] args) {
		int a[] = { 100,200,300,400,500};
//Methods for Declaration of arrays Arrays:
       //1.int []a = new int[100];
       //2.int a[] = new int[100];
//Initializing an array
      //int a[] = { 100,200,300,400,500};

/*int []a=new int[5];
       a[0] = 100;
       a[1] = 200;
       a[2] = 300;
       a[3] = 400;
       a[4] =	500;   */ 
//length of array	
    //System.out.println(a.length);
//Index of an array
     //System.out.println(a[3]);
//for loop
     /* for(int i=0;i<=4;i++) {
       System.out.println(a[i]); 
        }*/
//for each loop
   for(int x:a) {
     System.out.println(x);   
   }
   

 }
}
