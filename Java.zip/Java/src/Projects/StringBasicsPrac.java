package Projects;

public class StringBasicsPrac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         String a = "Manasa";
         String b = "Bethi";
         System.out.println(a);                  //Manasa
         System.out.println(b);                  //Bethi
      //lenth
         System.out.println(a.length());          //6
         System.out.println(b.length());          //5
      //Concat
         System.out.println(a.concat(b));         //ManasaBethi    
         System.out.println(a+b);                 //ManasaBethi 
      //Finding Character
         System.out.println(a.charAt(3));         //a
         System.out.println(b.contains("th"));    //true
      //trim
         String c = "   Bethi                    ";
         System.out.println(c.trim());             //Bethi
         System.out.println(c.length());           //28
         System.out.println(c.trim().length());    //5
     //
         String d ="Java";
         String e = new String("Java");
         System.out.println(d.equals(e));                      //true
         System.out.println(d.equalsIgnoreCase(e));            //true
         System.out.println(d.replace("va", "ck"));            //Jack
         System.out.println(d.replace("Java", "Selenium"));    //selenium
         System.out.println(e.substring(1, 3));                //av 
         System.out.println(d.toLowerCase());                  //java
         System.out.println(d.toUpperCase());                  //JAVA
     //Split
         String f = "manasabethi@gmail.com";  
         String g[] = f.split("@");
         System.out.println(g[0]);                             //manasabethi
         System.out.println(g[1]);                             //gmail.com
     //Split doesn't work with (.): Exception occurs  
        /* String h = "manasabethi@gmail.com";  
         String i[] = h.split(".");
         System.out.println(i[0]);
         System.out.println(i[1]);  */
         
	}

}
