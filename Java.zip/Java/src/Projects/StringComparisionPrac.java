package Projects;

public class StringComparisionPrac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//Case-1
           String a = "Strings";
           String b = "Strings";
           System.out.println(a==b);                  //true
           System.out.println(a.equals(b));           //true
     //case-2
           String c = "Programming";
           String d = new String("Programming");
           System.out.println(c);                     //Programming
           System.out.println(d);                     //Programming
           System.out.println(c==d);                  //True
           System.out.println(c.equals(d));           //True
     //case-3
           String e = "Arrays";
           String f = new String("Arrays");
           String g = f;
           System.out.println(e==f);
           System.out.println(e.equals(f));
           System.out.println(g==f);
           System.out.println(g.equals(f));
           
	}

}
