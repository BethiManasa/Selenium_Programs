package Projects;

public class StringComparisons {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "java";
		String s2 = "java";
		String s3 = new String("java");
//(==) Compares the reference variables or an object.
//(.euals) Compares the Value of an object.
		System.out.println(s1==s2);           //true
	    System.out.println(s1.equals(s2));    //true
		System.out.println(s1==s3);           //false
		System.out.println(s1.equals(s3));    //true
		
	//Case-2
		
		String s4 = "Java";
		String a  = new String("java");
		System.out.println(s3.equals(s4));    //false
		System.out.println(s4==a);            //false
		
    //case-3
		
		String m = "oops";
		String n = new String("oops");
		String o = n;
		System.out.println(m.equals(n));    //True
		System.out.println(m==n);           //false
		System.out.println(o==n);           //true
		System.out.println(o.equals(m));    //true
		
		
	}

}
