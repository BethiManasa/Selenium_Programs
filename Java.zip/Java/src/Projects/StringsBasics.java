package Projects;

public class StringsBasics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Declaration
		 String s = "Learning";
		 String s1 = new String("Java");  
		 
		System.out.println(s1);
		System.out.println(s);
	//length
		System.out.println(s.length()); 
	//concat
		System.out.println(s.concat(s1));
		//System.out.println(s1.charAt(0));
		//System.out.println(s.equals(s1));
		//System.out.println(s==s1);
        String s2 = "Concepts";
        String s3 = " Learning                    ";
      //+ Operator
        System.out.println(s+s1+s2);               //LearningJavaConcepts 
      //Removing Spaces 
        System.out.println(s3.trim());             //Learning
        System.out.println(s3.trim().length());    //8
        System.out.println(s3.length());           //29
        System.out.println(s1.charAt(0));          //J
        System.out.println(s2.contains("e"));      //true
        System.out.println(s2.contains("co"));     //false
        String a = "OOps";
        String b = "oops.com";
        String c = new String("Java");
        System.out.println(a.equals(b));            //false
      	System.out.println(a.equalsIgnoreCase(b));  //false
      	System.out.println(a==b);
      	System.out.println(a.replace("ps", "oo"));   //OOoo
      	System.out.println(b.replace("oops", "Selenium"));   //selenium.com
      	System.out.println(b.substring(1, 4));  //ops
      	
        String[] m = b.split("p");
        System.out.println(m[0]);      //oo
        System.out.println(m[1]);      //s.com
        System.out.println(b.toUpperCase());  //OOPS.COM
        System.out.println(a.toLowerCase());  //oops
        
        
	}

}
