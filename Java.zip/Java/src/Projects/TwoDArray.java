package Projects;

public class TwoDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//int a[][] = new int[3][2];
//int [][]a = new int[3][2];
//int []a[] = new int[3][2];
		/*a[0][0]= 100;
		  a[0][1]=200;
          a[1][0]=300;
          a[1][1]=400;
          a[2][0]=500;
          a[2][1]=600; */

		int b[][] = {{100,200},{200,400}};
		int d[][] = {
			        {100,200},
			        {300,400},
			        {500,600} };
		/*System.out.println(c[0][1]);//200
		System.out.println(c[0].length);//2
		System.out.println(c.length);//3 */
//for loop
	/*	for (int r=0;r<d.length;r++) {
			for (int c=0;c<d[r].length;c++) {
				System.out.print(d[r][c]+" ");
				
			}
			System.out.println();
		} */
//for each loop
		
		for (int x[]:d) {
			for(int y:x) {
				System.out.print(y+" ");
				
			}
			System.out.println();
		}
		
		
		}

	}

