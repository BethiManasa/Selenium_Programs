package OOPS;

public class Class1 extends Parent {
	int c;
	int d;
	double e;
	void sum2(int d,double e) {
		this.d=d;
		this.e=e;
		System.out.println("sum2: "+(d+e));
		
	}
   void sum3() {
	   System.out.println("Manasa");
   }
}
