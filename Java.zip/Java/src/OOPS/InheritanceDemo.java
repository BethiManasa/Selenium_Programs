package OOPS;


interface Shape{
	int length=10;
	int width=20;
	
	void circle();                              //abstract method
	
	default void square() {                     //creating default method.
		System.out.println("It's a square");
		
	}
	static void rectangle() {
		System.out.println("It's a Rectangle");
	}
	
}
public class InheritanceDemo implements Shape {

	@Override
	public void circle() {
		System.out.println("It's a circle");
		
	}
	public static void main(String[] args) {
		InheritanceDemo sh = new InheritanceDemo();
	                        
		sh.square();
		Shape.rectangle();
		sh.circle();
	}

}
