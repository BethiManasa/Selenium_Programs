package OOPS;


	 class MethodOverride {
			void roi() {
				System.out.println("hi");
			}
		}
		class ICICI extends MethodOverride {
		 
			void roi() {
				System.out.println("Good");
				
			}
		}
		class HDFC extends MethodOverride {
//			void roi() {
//				System.out.println("Bye");
//			}
		}
		
		public  class Methodoverriding_1{
		 public static void main(String[] args) {
			 ICICI i = new ICICI();
			 i.roi();
			 HDFC s = new HDFC();
			 s.roi();
			 
			
		}
	
		 
			}
			
		




