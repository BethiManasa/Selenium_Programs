package OOPS;

public class ClassA {
	int a;
	int b;
	String c;
	void sum() {
		System.out.println("Manasa");
	}
	void sum1(int a,int b) {
		this.a=a;
		this.b=b;
		System.out.println(a+b);
	}
}

