package OOPS;

public class Class3 extends Parent{
	int o;
	int p;
	String q;
	public void add2(int o,String q) {
		this.o=o;
		this.q=q;
		System.out.println("Add: "+(o+q));
		
	}

}
