package OOPS;

public class MethodOverloading {
	int a , b;
	double c;
	String s;
  void add() {
	  System.out.println("Manasa");
  }
  void add(int x,int y) {
	  a = x;
	  b = y;
	  System.out.println(x+" "+y);
	  System.out.println(x+y);
	  
  }
  void add(int x,double z) {
	  a = x;
	  c = z;
	  System.out.println(x+" "+z);
	  System.out.println(x+z);
  }
  void add(int x,double z,String d) {
	   a = x;
	   c = z;
	   s = d;
	   System.out.println(x+" "+z+" "+d);
		  System.out.println(x+z+d);
  }
  public static void main(String[] args) {
	  MethodOverloading m = new MethodOverloading() ;
	  m.add();
	  m.add(5, 7); 
	  m.add(5, 10.0);
	  m.add(5, 10.0,"abc");
		  
	 
}
}
