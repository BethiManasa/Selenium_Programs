package OOPS;

public class SingleInheritance {
		public static void main(String[] args) {
			ClassB b = new ClassB();
			b.sum();
			b.sum1(10, 20);
			b.add();
			b.add1(10,"Manasa");
			
		}
	}
	


