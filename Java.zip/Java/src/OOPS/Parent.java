package OOPS;

public class Parent {
	int a;
	int b;
	String s;
	void sum() {
		System.out.println("Hi");
	}
	void sum1(int b,String s) {
		this.b=b;
		this.s=s;
		System.out.println(b);
		System.out.println(s);
		
	}

}
