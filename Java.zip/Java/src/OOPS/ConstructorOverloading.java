package OOPS;

public class ConstructorOverloading {
	int a,b;
	double c;
	ConstructorOverloading (){
		System.out.println("Manasa");
		
	}
	ConstructorOverloading (int x,int y){
		a = x;
		b = y;
		System.out.println(a+" "+b);
		System.out.println(a+b);
		
	}
	ConstructorOverloading (int x,int y,double z){
		a = x;
		b = y;
		c = z;
		System.out.println(a+" "+b+" "+c);
		System.out.println(a+b+c);
		
	}
	public static void main(String[] args) {
		ConstructorOverloading c = new ConstructorOverloading();
		ConstructorOverloading s =new ConstructorOverloading(10,20);
		ConstructorOverloading m =new ConstructorOverloading(10,20,30.00);

	}
}
