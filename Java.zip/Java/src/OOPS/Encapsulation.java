package OOPS;

public class Encapsulation {
	
	private int a;
	private char b;
	private String c;
	
//Getter & Setter - from source
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public char getB() {
		return b;
	}
	public void setB(char b) {
		this.b = b;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
 public static void main(String[] args) {
	 Encapsulation e = new Encapsulation ();
	 e.setA(3);
	 System.out.println(e.getA());
	 e.setB('A');
	 System.out.println(e.getB());
	 e.setC("Manasa");
	 System.out.println(e.getC());
	}

}
