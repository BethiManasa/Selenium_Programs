package OOPS;

public class ThisKeyword {
//using Method
	/*int a,b;
	double c;
	void sum(int a,int b,double c) {
		this.a = a;
		this.b = b;
		this.c = c;
		System.out.println("sum of:" +(a+b+c));
	}
	void sum1(int a,double c) {
		this.a = a;
		this.c = c;
		System.out.println("sum of:" +(a+c));
	}
	public static void main(String[] args) {
		ThisKeyword t = new ThisKeyword();
		t.sum(10, 20, 30.1);
		t.sum1(10, 30.1);
	}*/
//using constructor
	int a,b;
	double c;
	ThisKeyword (int a,int b,double c) {
		this.a = a;
		this.b = b;
		this.c = c;
		System.out.println("sum of:" +(a+b+c));
	}
	ThisKeyword (int a,double c) {
		this.a = a;
		this.c = c;
		System.out.println("sum of:" +(a+c));
	}
	public static void main(String[] args) {
		ThisKeyword t = new ThisKeyword(10,20,20.1);
		ThisKeyword t1 = new ThisKeyword(10,20.1);
		
}
}
