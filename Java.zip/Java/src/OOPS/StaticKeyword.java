package OOPS;

public class StaticKeyword {
	static int a,b;
	static double c;
//static: No need of creating object &can directly call the methods.
	static void name() {
		System.out.println("Manasa");	
	}
	static void add(int x,int y) {
		a = x;
		b = y;
		System.out.println("Sum of num:" +(a+b));	
	}
	static void sum(int x,int y,double z) {
		a = x;
		b = y;
		c = z;
		System.out.println("Sum of num1:" +(a+b+c));	
	}
	public static void main(String[] args) {
		name();
		add(10, 20);
		sum(10, 20, 30.5);
	}
}
