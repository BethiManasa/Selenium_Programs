package OOPS;

class Dog extends Animal{
	String color="Black";
	void eat1() {
		System.out.println("Eat meat");
	}
	void display() {
		System.out.println(color);
		System.out.println(super.color);
	}
	public static void main(String[] args)
	 
	{
 
		Dog d=new Dog();
 
		d.display();
 
		d.eat();
		d.eat1();
 
	}

	
}
 

