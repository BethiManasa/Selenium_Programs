package OOPS;

//Super class
 class Animal { 
	String color="White";
	void eat() {
		System.out.println("Eating");
	}
}
 
