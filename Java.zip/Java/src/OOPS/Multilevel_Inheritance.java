package OOPS;

public class Multilevel_Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassC c = new ClassC();
		c.add();
		c.sum();
		c.sum1(10, 20);
		c.add();
		c.add1(10,"Manasa");
		c.sum2('A', "Manasa");
		c.Sum3("Java", 10);

	}

}
