package OOPS;

public class Hierarchy {
	
	public static void main(String[] args) {
		Class1 c1 = new Class1();
		c1.sum();
		c1.sum1(5, "Mansa");
		c1.sum2(3, 5.5);
		Class2  c2 = new Class2();
		c2.add();
		c2.add1(7);
		Class3 c3 = new Class3();
		c3.add2(6, "abc");
		
	}

}
