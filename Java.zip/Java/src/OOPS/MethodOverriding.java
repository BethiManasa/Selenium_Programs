package OOPS;

class MethodOverridingg {
	int roi() {
		return 10;
	}
}

class ICIC extends MethodOverridingg {

	int roi() {
		return 20;
	}
}

class SBI extends MethodOverridingg {
	int roi() {
		return 30;
	}
}

public class MethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ICIC i = new ICIC();
		System.out.println(i.roi());
		SBI s = new SBI();
		System.out.println(s.roi());

	}

}
