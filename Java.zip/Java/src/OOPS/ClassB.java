package OOPS;

public class ClassB extends ClassA {
	int d;
	int e;
	String f;
	

void add() {
	System.out.println("Java");
}
void add1(int d,String f) {
	this.d=d;
	this.f=f;
	System.out.println(d);
	System.out.println(f);
}
}


