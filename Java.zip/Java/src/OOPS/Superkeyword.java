package OOPS;

public class Superkeyword {
	public static void main(String[] args) {
		Dog d=new Dog();
		d.display();
		d.eat1();
		d.eat();
 
	}

}
