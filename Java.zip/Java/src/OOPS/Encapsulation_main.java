package OOPS;

public class Encapsulation_main {
	 public static void main(String[] args) {
		 Encapsulation e = new Encapsulation ();
		 e.setA(3);
		 System.out.println(e.getA());
		 e.setB('A');
		 System.out.println(e.getB());
		 e.setC("Manasa");
		 System.out.println(e.getC());
		}
		

}
