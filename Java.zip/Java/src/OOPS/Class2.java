package OOPS;

public class Class2 extends Parent{
	int m;
	int n;
	public void add() {
		System.out.println("Hi");
		
	}
	public void add1(int m) {
		this.m=m;
		System.out.println(m);
		
	}

}
