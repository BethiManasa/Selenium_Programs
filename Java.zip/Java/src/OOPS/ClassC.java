package OOPS;

public class ClassC extends ClassB {
	int m;
	char n;
	String o;
	public void sum2(char n,String o) {
		this.n=n;
		this.o=o;
		System.out.println(n);
		System.out.println(o);
		
	}
	public void Sum3(String o,int m) {
		this.o=o;
		this.m=m;
		System.out.println(o);
		System.out.println(m);
		
	}

}
