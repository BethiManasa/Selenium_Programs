package WrapperClasses;

public class Autoboxing {

	
	public static void main(String[] args) {
		
//Autoboxing : conversion of primitive data types into its equivalent Wrapper type
		
		int i = 10;
		Integer a = new Integer(i);
		
		System.out.println(i);
		

	}

}
