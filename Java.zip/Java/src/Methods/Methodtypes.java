package Methods;

public class Methodtypes {
	
//No return type & No returntype
  /*	void dispaly() {
		System.out.println("Java");
	}

	public static void main(String[] args) {
		Methodtypes m = new Methodtypes();
		m.dispaly();
		

	}*/
//Returntype & No parameters
   /*	String show() {
		String s = "Manasa";
		return s;
	}
	
	public static void main(String[] args) {
		Methodtypes m = new Methodtypes();
		System.out.println(m.show());
   } */
//No Returntype & passing parameters
	 /*void dispaly(String s) {
		System.out.println("Java " +s);
	}
	public static void main(String[] args) {
		Methodtypes m = new Methodtypes();
	        m.dispaly("Concepts");
		
	
    }*/
//Return Type &Passing parameters
	String show(String a) {
		return a;
		
	}
	public static void main(String[] args) {
		Methodtypes m = new Methodtypes();
	        
	        System.out.println(m.show("Manasa"));
  }
}