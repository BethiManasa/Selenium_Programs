package Methods;

public class Student {
         int id;
         String Name;
  //Non Returntype
       void display() {
    	   System.out.println(id+ " " +Name);
    	   
       }
  //Return type-String
       String show() {
    	   String a = "Learning java";
    	   return a;
    	  
    	   
       }
  //Return type-int
       int show1() {
    	   int a=10;
    	   int b=20;
    	   int c= a+b;
    	   return c;
       }
  //Return type - char
       char Show2() {
    	   char a = 'a';
    	   return a;
       }
  // Main method
       public static void main(String[] args) {
  //creating object
		 Student s = new Student();
		 s.id = 1159;
		 s.Name="Manasa";
		 s.display();
		System.out.println(s.show());
		System.out.println(s.show1()); 
		System.out.println( s.Show2());
	}
}
