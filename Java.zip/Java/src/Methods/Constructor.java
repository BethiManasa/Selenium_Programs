package Methods;

public class Constructor {

	
	int id;
	String s;
//Default Constructor
   /*	Constructor(){
		 id = 10;
		 s = "Manasa";
	} 

	 void show() {
		  System.out.println(id+ " "+s);
		  
		  
	  }
    public static void main(String[] args) {
	Constructor c = new Constructor();
	c.show();
    }*/
//parameterized constructor:
		Constructor(int id1,String s1){
			id = id1;
			s=s1;
			
			
		}
		 void show() {
			  System.out.println(id+ " "+s);
			  
			  
		  }
	    public static void main(String[] args) {
		Constructor c = new Constructor(10,"Manasa");
		c.show();
	    }
}
