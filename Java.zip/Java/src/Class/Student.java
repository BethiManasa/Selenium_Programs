package Class;

public class Student {

//1.By Reference Variables

	  int id;
	  String Name;
	  float Marks;
	  char grade;
	  
	public void display() {
		System.out.println(id);
		System.out.println(Name);
		System.out.println(Marks);
		System.out.println(grade);
	}
	public static void main(String[] args) {
		 Student S2 = new Student();
		    S2.id = 1159;
		    S2.Name= "Manasa";
		    S2.Marks=85;
		    S2.grade='A';
		 S2.display();
	}
}
