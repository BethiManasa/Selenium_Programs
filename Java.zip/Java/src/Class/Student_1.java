package Class;

public class Student_1 {
	
	int id = 5;
	String Name="Mansa";
	float Marks= 89;
 
	public void display() {
		System.out.println(id+" " +Name+" " +Marks);
	}
	public static void main(String[] args) {
		Student_1 S = new Student_1();
		
		S.display();
	}
}
    
