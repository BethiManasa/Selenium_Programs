package Class;

public class Employee {
	
//2.By Method
	
	int eid;
	String eName;
	char eGrade;
	
	void display() {
		System.out.println(eid);
		System.out.println(eName);
		System.out.println(eGrade);
	
	}
    /* void setdata(int id,String Name,char Grade) {
		eid = id;
		eName=Name;
		eGrade=Grade;
		
	}*/
   // public static void main(String[] args) {
		/*Employee E = new Employee();
			E.setdata(1159,"Manasa",'A'); */
	
//3.By constructor 
	
	 Employee(int id,String Name,char Grade) {
		eid = id;
		eName=Name;
		eGrade=Grade;  }
	public static void main(String[] args) {	
     Employee E = new Employee(1159,"Mansa",'A');
			E.display();

	}
	

}
