package Collections;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//    1) Heterogenious data - allowed
//	2) Insertion order- preserved(Index)
//	3) Duplicate elements -- allowed
//	4) multiple nulls -- allowed
//Declarations of an ArrayList
		ArrayList list = new ArrayList();
	//ArrayList<Integer> l1 = new ArrayList<Integer>();
    //ArrayList<String> l2 = new ArrayList<String>();
	//List l = new ArrayList();
		list.add(100);
		list.add(null);
		list.add("Manasa");
		list.add('A');
		list.add(10.5);
		list.add(0);
		list.add(null);
		list.add(9);
		list.add(3, "Bethi");
		System.out.println("MyList: " +list);
		System.out.println(list.get(3));
		System.out.println(list.size());
		list.remove(1);
		System.out.println("MyList after removing: " +list);
	/*	for (Object a : list) {
			System.out.println( a);
			
		} */
		for(int i=0;i<list.size();i++) {
			System.out.println(list.get(i));
		}

}
}
