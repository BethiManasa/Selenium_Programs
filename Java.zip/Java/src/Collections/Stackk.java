package Collections;

import java.util.Stack;

public class Stackk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Stack<String> books = new Stack<>();
      books.push("English");
       books.push("Maths");
       books.push(null);
     //  books.push(0, "Physics");
       books.push("Chemistry");
     //  System.out.println(books);
      
     /*  System.out.println( books.remove("Chemistry"));
       books.set(1, "Telugu");
      System.out.println(books); */
 //Methods: Push,pop,peek,Search
   System.out.println(books.peek());
   System.out.println(books);
   System.out.println(books.search("English"));
   System.out.println(books.indexOf("English"));
   System.out.println(books.pop());
   System.out.println(books);
   System.out.println(books.isEmpty());
 /* Default Capacity: 10
  * Initial Capacity: 10
  * 
  */
   
 	}

}
