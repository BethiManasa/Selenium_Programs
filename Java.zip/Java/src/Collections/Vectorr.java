package Collections;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Vector;

public class Vectorr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  //Duplicate Elements are allowed
  //Multiple nulls are allowed
  //Insertion order is followed
  // SIZE: No of elements Present in list 
  //CAPACITY: Array Capacity[10]
  //Best for Multithreading
	/*	Vector v = new Vector();
		v.add("Manasa");
		v.add("Bethi");
		v.add(0, "Pranitha");       //specifying index
		v.add("Sumana");
		v.add("SUpraja");
		Vector v1 = new Vector();
		v1.add("Raju");
		v1.add("Vinay");
		v1.add("Jelly");
		System.out.println(v);  */
//		for (int i=0;i<v1.size();i++) {
//			v.add(v1.get(i));
//		}
       /* v.addAll(v1);
		System.out.println(v); */
   //		System.out.println(v.size());
   //		System.out.println(v.capacity());
//Retreiving data: get()
//Deleting: remove,removeAll
		/*System.out.println(v.get(1));
		System.out.println(v1.remove(0));
		v1.remove("Jelly");
		//v.removeAll(v);
		System.out.println(v1); */
//Verfication: Contains,Contains All
//		System.out.println(v1.contains("Manasa"));
//		System.out.println(v1.containsAll(v));
//Updation: set
		/*v1.set(0, "Manasa");
		System.out.println(v1);
		Object[] arr = v.toArray();
		System.out.println(Arrays.toString(arr));*/
   Object[] arr = new Object[] {1,1,5,9,2};
    Vector v = new Vector(Arrays.asList(arr));
    System.out.println(v);
    System.out.println(v.size());
    System.out.println(v.capacity());
	}

}
