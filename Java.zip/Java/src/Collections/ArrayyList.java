package Collections;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayyList {

	public static void main(String[] args) {
		// TODO Auto-generated method st
  //Default Capacity - 0
  //Initial Capacity of Array List is increased once the element is added to it.
		ArrayList<Integer> a = new ArrayList<>();
		a.add(10);
		a.add(0, 20);
		a.add(null);
		a.add(10);
		a.add(30);
		a.add(null);
		System.out.println(a.size());
        a.remove(null);
        a.set(1,11);
        System.out.println(a);
        for (Integer integer : a) {
        	System.out.print(integer+" ");
			
		}
    //Sychronization should be applied Explicitly(By default there is no Synchronisation)
     //   Collections.synchronizedList(a);   --->Acts as Vector
     //Arraylist doesnt increase exponentially.
	}

}
