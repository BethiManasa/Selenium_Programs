package Collections;

import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
//		Data can be stored in the form of key, value pairs.
//		Key is unique. But we can have duplicate values.
//		Insertion order not preserved(Index not followed)
		// TODO Auto-generated method stub
		Map m = new HashMap();
		m.put(1, "ab");
		m.put(7, 8);
		m.put(2, "cd");
		m.put(3, "bd");
		m.put(1, "hi");
		m.put(5, "z");
		m.put(6, 'A');
		System.out.println(m);
		System.out.println(m.size());
		m.remove(2);
		System.out.println("After removing:" +m);
		m.remove(1, "hi");
		System.out.println(m);
		System.out.println(m.keySet());
		System.out.println(m.values());
		
		
		
		for (String s : args) {
			System.out.println(s);
			
		}
		
		m.clear();
		System.out.println(m);

		

	}
	
}
