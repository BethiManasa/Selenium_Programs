package Collections;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//	1) Heterogenios data ---> allowed
//	2) Insertion order  --> Not preserved (Index not supported)
//	3) Duplicate elements --> Not Allowed
//	4) Multiple nulls Not allowed/ only single null is allowed
		HashSet h = new HashSet();
		h.add(100);
		h.add(null);
		h.add("Manasa");
		h.add('A');
		h.add(10.5);
		h.add(0);
		h.add(null);
		h.add(9);
		//h.add(3, "Bethi");
		System.out.println("MySet: " +h);
		//System.out.println(h.get(3));
		System.out.println(h.size());
		h.remove(100);
		System.out.println("MyList after removing: " +h);
		for (Object s : h) {
			System.out.println(s);
			
		}

	}

}
