package Practice;

public class PrintingName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s ="Manasa";
		for(int i=0;i<s.length();i++){
			System.out.println(s.charAt(i));
		}

	}

}
