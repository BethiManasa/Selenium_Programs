package Practice;
public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String a= "Manasa Bethi";
		String rev = "";
//		for(int i=a.length()-1;i>=0;i--) {
//			rev = rev+a.charAt(i);
//		}
		 for (int i = 0; i < a.length(); i++) {
		      rev= a.charAt(i) + rev;
		    }
		
		System.out.println("The reverse String is:" +rev);
		

	}

}
