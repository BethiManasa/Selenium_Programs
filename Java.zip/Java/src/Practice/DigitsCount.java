package Practice;

import java.util.Scanner;

public class DigitsCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Enter Number:");
		Scanner sc = new Scanner(System.in);
		int n= sc.nextInt();
		int count = 0;
		while(n>0) {
			n = n/10;
			count++;
			
		}
		System.out.println("The number of digits are:"+count);

	}

}
