package Practice;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Number:");
		Scanner sc = new Scanner(System.in);
	int n = sc.nextInt();
//	
//		int fact=1;
//		for(int i=2;i<=n;i++) {
//			fact = fact*i;
//		}
//       System.out.println("The factorial is:"+fact);
		int fact =1;
		for(int i=2;i<=n;i++) {
			fact = fact*i;
		}
		System.out.println(fact);
	}

}
