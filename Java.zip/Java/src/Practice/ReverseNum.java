package Practice;

import java.util.Scanner;

public class ReverseNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Enter Number:");
		Scanner sc = new Scanner(System.in);
		int n= sc.nextInt();
		
        int reverse=0;
        while(n!=0) {
       int reminder = n%10;
       reverse = reverse*10+reminder;
       n = n/10;
       
    }
        
        System.out.println("reverse:" +reverse);

} 
	
}
