package Practice;

public class ReverseNormal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String a = "Manasa Bethi";
		char[] c = a.toCharArray();
		int left=0;
		int right = a.length()-1;
		while(left<right) {
			char temp = c[left];
			c[left] = c[right];
			c[right]=temp;                                                                                     
			left++;
			right--;
		}
		 String reversedString = new String(c);
	        
	        // Print the reversed string
	        System.out.println("Reversed string: " + reversedString);
	}

}
