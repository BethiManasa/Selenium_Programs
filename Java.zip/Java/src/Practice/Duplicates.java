package Practice;
import java.util.LinkedHashSet;

public class Duplicates {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    String s = "Manasa Bethi";
//    LinkedHashSet<Character> set = new LinkedHashSet<>();
//    for (Character c :s.toCharArray()) {
//    	set.add(c);
//    }
//		String res = "";
//		for (Character c : set) {
//			set.add(c);
//			res = res+c;
//		}
//		System.out.println(res);
    char ch[] = s.toCharArray();
    LinkedHashSet<Character> set = new LinkedHashSet<>();
    for (Character c : ch) {
    	set.add(c);
		
	}
    String res ="";
    for (Character c : set) {
    	res = res+c;
		
	}
    System.out.println(res);
  
}

}
