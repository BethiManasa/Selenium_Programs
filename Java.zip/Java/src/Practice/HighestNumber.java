package Practice;

public class HighestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {10,30,90,40};
		int highNum = a[0];
		for(int i=0;i<a.length;i++) {
			if(a[i]>highNum) {
				highNum = a[i];
			}
		}
   System.out.println(highNum);      
	}

}
