package Practice;

import java.util.HashMap;

public class CharOccurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a ="Manasa";
		char ch[] = a.toCharArray();
//		HashMap<Character, Integer> map = new HashMap<>();
//		for (char c : ch) {
//			if(map.containsKey(c)) {
//				map.put(c, map.get(c)+1);
//			}
//			else {
//				map.put(c, 1);
//			}
//			System.out.println(map);
//		}
//		
     HashMap<Character, Integer> map =new  HashMap<Character, Integer>();
     for (char c : ch) {
    	 if(map.containsKey(c)) {
    		 map.put(c, map.get(c)+1);
    	 }
    	 else {
    		 map.put(c, 1);
    	 }
    	
	}
     System.out.println("The Occurance of Character: "+map);
	}

}
