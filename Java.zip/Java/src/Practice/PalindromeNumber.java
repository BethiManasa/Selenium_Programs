package Practice;

import java.util.Scanner;

public class PalindromeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the Number:");
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b =a;
		int rev=0;
		while(a>0) {
			int rem = a%10;
			rev =rev*10+rem;
			a = a/10;		

	}
   if(b==rev) {
	   System.out.println("Number is Palindrome");
   }
   else {
	   System.out.println("Number is not a palindrome");
   }
}
}
