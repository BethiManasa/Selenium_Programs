package Practice;

public class AsciiValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a='A';
		char B ='b';
		int valuea = a;
		int valueB = B;
		System.out.println("The Value of a is:"+valuea);
		System.out.println("The value of B is:"+valueB);

	}

}
