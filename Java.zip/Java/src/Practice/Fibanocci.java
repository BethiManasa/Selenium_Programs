package Practice;

import java.util.Scanner;

public class Fibanocci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter Number: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
        int f =1;int s=1;int t;
        System.out.println(f);
        System.out.println(s);
//        for(int i=3;i<=n;i++) {
//        	t = f+s;
//        	System.out.println(t);
//         f = s;
//         s = t;
//        }
        for(int i=3;i<=num;i++) {
        	t=f+s;
        	System.out.println(t);
        	f=s;
        	s=t;
        }
	}
	

}
