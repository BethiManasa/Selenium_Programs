package Practice;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "abcdcba";
//		String rev= "";
//		for(int i=0;i<a.length();i++) {
//			rev = rev+a.charAt(i);
//		}
//		if(a.equals(rev)) {
//			System.out.println("It is a palindrome");
//		}
//		else {
//			System.out.println("It is not a Palindrome");
//		}
		int i=0; int j =a.length()-1;
		while(i<j) {
			if(a.charAt(i)!=a.charAt(j)) {
				System.out.println("Not a Palindrome");
			}
			i++;
			j--;
		}
   System.out.println("It is a Palindrome");
	}

}
