package Exceptions;

import java.util.Scanner;

public class ArrayIndexOfBounds {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program started");
		System.out.println("Program is in Progress");
		
		int a[]=new int[5]; 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int num=sc.nextInt();
		System.out.println("Enter position:");
		int pos=sc.nextInt();
		
		a[pos]=num;
		
	    System.out.println();
		System.out.println("program Exited");

	}

}
