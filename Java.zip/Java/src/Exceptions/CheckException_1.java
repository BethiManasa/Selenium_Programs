package Exceptions;

public class CheckException_1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("program is started....");
		System.out.println("program is in progress....");
		Thread.sleep(5000);
		
		System.out.println("program is finished....");
		System.out.println("program is terminated....");
	}

}
