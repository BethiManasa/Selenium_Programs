package Exceptions;

import java.util.Scanner;

public class ArithException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program started");
		System.out.println("Program is in Progress");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter num:");
		int num = sc.nextInt();
		
	  /*  try {
	    	 System.out.println(100/num);
	    }
	    catch (Exception e) {
			// TODO: handle exception
		     e.printStackTrace();
	       System.out.println(e.getMessage());
	    }*/
		
//multiple Catch blocks
		
		try {
			System.out.println(100/num);
		}
		catch(ArithmeticException a) {
			System.out.println("Arith Exception thrown");
		}
		catch(NullPointerException n){
			System.out.println("Null Exception thrown");
		}
		catch(ArrayIndexOutOfBoundsException ar) {
			System.out.println("Array Exception thrown");
		}
//finally - used regardless of exception the line of code to be run is given in finally.
		finally {
			System.out.println("Execution is done");
		}
	    
		System.out.println("program Exited");

	}

}
