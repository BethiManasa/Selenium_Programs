package Webpages;

//Import statements are used to include necessary classes from external packages.
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Degreed.DriverClass;

//Class declaration for Baseclas, which extends DriverClass.
public class Baseclas extends DriverClass {

	// Method to perform a click action on a WebElement.
	public void clickmethod(WebElement e) {

		// Using the click() method of the WebElement class to perform a click action
		e.click();
	}

	// Method to send keys to a WebElement, typically used for input fields.
	public void sendKeys(WebElement e, String s) {

		// Using the sendKeys() method of the WebElement class to input text.
		e.sendKeys(s);
	}

}
