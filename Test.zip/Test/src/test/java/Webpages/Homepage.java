package Webpages;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Homepage extends Baseclas {

	WebDriver driver;

	// Constructor to initialize the WebDriver
	public Homepage(WebDriver driver) {
		this.driver = driver;
	}

	// Locators for elements on the homepage
	By next = By.xpath("//div[@class='tool']//a[@title='Next'][normalize-space()='Next']");
	By uname = By.xpath("//input[@id='username']");
	By cont = By.xpath("//span[@class='df-spinner-button__content']");
	By click = By.xpath("//span[@class='df-spinner-button__content']");
	By feature = By.xpath("//a[normalize-space()='Featured']");
	By AI = By.linkText("GENERATIVE AI CAMPUS");

	
	// Method to click on the 'Next' button
	public void next() {

		WebElement f = driver.findElement(next);
		clickmethod(f);
		
		

	}

	// Method to enter username
	public void unam_e() {
		
		// Switching to the new window
		String parent_window = driver.getWindowHandle(); // parent win
		Set<String> set = driver.getWindowHandles();
		Iterator<String> I = set.iterator();
		while (I.hasNext()) {
			String child_window = I.next();
			if (!(parent_window.equals(child_window))) {
				driver.switchTo().window(child_window);
			}
		}

		WebElement e = driver.findElement(uname);

		sendKeys(e, "anusha.kanukondla@capgemini.com");
	}

	// Method to perform some action related to contact
	public void con_t() {
		WebElement w = driver.findElement(cont);
		clickmethod(w);
	}

	// Method to perform a click action
	public void clic_k() {
		WebElement b = driver.findElement(click);
		clickmethod(b);
	}

    // Method to click on the 'Featured' link and scroll down
	public void featur_e() {
		WebElement c = driver.findElement(feature);
		clickmethod(c);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0,500)");
	}

	// Method to click on the 'GENERATIVE AI CAMPUS' link
	public void Ai() {
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		WebElement d = driver.findElement(AI);
		clickmethod(d);
	}

    // Method to validate something on the page
	public void validate() {
		String actualConfirm = driver.findElement(By.xpath("//h1")).getText();
		String expectedConfirm = "GENERATIVE AI CAMPUS";
		Assert.assertEquals(actualConfirm, expectedConfirm);
		System.out.println(actualConfirm);

	}

	// Method to perform some action related to future
	public void future() throws InterruptedException {
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 500)");
		Thread.sleep(3000);
		String actual = driver
				.findElement(By.xpath("//h2[contains(text(),'GET STARTED BY COMPLETING THE GENERATIVE AI REQUIR')]"))
				.getText();
		String expected = "GET STARTED BY COMPLETING THE GENERATIVE AI REQUIRED PATHWAYS";
		Assert.assertEquals(actual, expected);
		System.out.println(actual);

	}

	// Method to perform some action related to development
	public void Develop() throws InterruptedException {
		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 1000)");
		Thread.sleep(3000);

		String actualdev = driver.findElement(By.xpath("//h2[normalize-space()='YOU AND GENERATIVE AI']")).getText();
		String expecteddev = "YOU AND GENERATIVE AI";
		Assert.assertEquals(actualdev, expecteddev);
		System.out.println(actualdev);

	}

	// Method to perform some action related to listening
	public void listen() throws InterruptedException {

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 300)");
		Thread.sleep(3000);

		String actuallisten = driver
				.findElement(By.xpath("//h2[contains(text(),'EXPAND YOUR CAPABILITIES UTILIZING GENERATIVE AI T')]"))
				.getText();
		String expectedlisten = "EXPAND YOUR CAPABILITIES UTILIZING GENERATIVE AI TOOLS AND SERVICES";
		Assert.assertEquals(actuallisten, expectedlisten);
		System.out.println(actuallisten);

	}

	// Method to perform some action related to expertise
	public void expert() throws InterruptedException {

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 1000)");
		Thread.sleep(6000);

		String actualexp = driver
				.findElement(By.xpath("//h2[contains(text(),'FURTHER YOUR KNOWLEDGE OF GENERATIVE AI WITH OUR A')]"))
				.getText();
		String expectedexp = "FURTHER YOUR KNOWLEDGE OF GENERATIVE AI WITH OUR ALLIANCE PARTNERS";
		Assert.assertEquals(actualexp, expectedexp);
		System.out.println(actualexp);

	}

	// Method to explore something
	public void explore() throws InterruptedException {

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 300)");
		Thread.sleep(6000);

		String actualexpl = driver
				.findElement(By.xpath("//h2[normalize-space()='TAKE YOUR GENERATIVE AI KNOWLEDGE FURTHER']")).getText();
		String expectedexpl = "TAKE YOUR GENERATIVE AI KNOWLEDGE FURTHER";
		Assert.assertEquals(actualexpl, expectedexpl);
		System.out.println(actualexpl);
	}

	// Method to perform some action related to generation
	public void Gen() throws InterruptedException {

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 500)");
		Thread.sleep(6000);

		String actualge = driver.findElement(By.xpath("//h2[normalize-space()='GENERATIVE AI INNOVATION']")).getText();
		String expectedge = "GENERATIVE AI INNOVATION";
		Assert.assertEquals(actualge, expectedge);
		System.out.println(actualge);
	}

	// Method to perform some action related to staying connected
	public void Stay() throws InterruptedException {

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 600)");
		Thread.sleep(6000);

		String actualstay = driver
				.findElement(By.xpath("//h2[normalize-space()='STAY CONNECTED WITH GENERATIVE AI EVENTS']")).getText();
		String expectedstay = "STAY CONNECTED WITH GENERATIVE AI EVENTS";
		Assert.assertEquals(actualstay, expectedstay);
		System.out.println(actualstay);

	}

	// Method to register for events
	public void Register() throws InterruptedException {

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 300)");
		Thread.sleep(6000);

		String actualstay = driver
				.findElement(By.xpath("//h2[normalize-space()='REGISTER FOR HYPERSCALERS-SPONSORED EVENTS']"))
				.getText();
		String expectedstay = "REGISTER FOR HYPERSCALERS-SPONSORED EVENTS";
		Assert.assertEquals(actualstay, expectedstay);
		System.out.println(actualstay);
	}

	
	public void Events() throws InterruptedException {

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 500)");
		Thread.sleep(6000);

		String actualreg = driver
				.findElement(By.xpath("//h2[normalize-space()='REGISTER FOR CAPGEMINI INTERNAL EVENTS']")).getText();
		String expectedreg = "REGISTER FOR CAPGEMINI INTERNAL EVENTS";
		Assert.assertEquals(actualreg, expectedreg);
		System.out.println(actualreg);
	}

	public void Discover() throws InterruptedException {

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 500)");
		Thread.sleep(6000);

		String actualdis = driver
				.findElement(By.xpath("//h2[contains(text(),'DISCOVER DIFFERENT GENERATIVE AI PERSPECTIVES FROM')]"))
				.getText();
		String expecteddis = "DISCOVER DIFFERENT GENERATIVE AI PERSPECTIVES FROM AROUND THE BUSINESS";
		Assert.assertEquals(actualdis, expecteddis);
		System.out.println(actualdis);

	}

	public void Skill() throws InterruptedException {
		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 900)");
		Thread.sleep(6000);

		String actualsk = driver
				.findElement(By.xpath("//h2[contains(text(),'DEVELOP SKILLS THAT COMPLEMENT YOUR GENERATIVE AI')]"))
				.getText();
		String expectedsk = "DEVELOP SKILLS THAT COMPLEMENT YOUR GENERATIVE AI DEVELOPMENT";
		Assert.assertEquals(actualsk, expectedsk);
		System.out.println(actualsk);

	}

	public void Offers() throws InterruptedException {

		JavascriptExecutor jse = (JavascriptExecutor) driver;// Scroll method
		jse.executeScript("window.scrollBy(0, 500)");
		Thread.sleep(6000);

		String actualoffer = driver
				.findElement(By.xpath("//h2[normalize-space()='EXPLORE ALL CAPGEMINI LEARNING OFFERS']")).getText();
		String expectedoffer = "EXPLORE ALL CAPGEMINI LEARNING OFFERS";
		Assert.assertEquals(actualoffer, expectedoffer);
		System.out.println(actualoffer);

	}

}