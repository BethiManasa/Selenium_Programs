package Degreed;

import org.testng.annotations.Test;

import Webpages.Homepage;

public class Homepage_Test extends DriverClass {

	// This annotation denotes that this method is a test case to be executed by TestNG
	@Test
	public void Test() throws Exception {
		
		// Instantiate the Homepage class with the driver instance
		Homepage h = new Homepage(driver);
		
		// Perform various actions on the homepage objec
		h.next();
		h.unam_e();
		h.con_t();
		h.clic_k();
		h.featur_e();
		h.Ai();
		h.validate();
		h.future();
		h.Develop();
		h.listen();
		h.expert();
		h.explore();
		h.Gen();
		h.Stay();
		h.Register();
		h.Events();
		h.Discover();
		h.Skill();
		h.Offers();
		
	

	}

}
