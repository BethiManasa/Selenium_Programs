package Degreed;

// Import statements are used to include necessary classes from external packages.
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;


import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverClass {

	public static WebDriver driver;
	

	@BeforeSuite
	public void Openbrowser() {

		// Setup WebDriver using WebDriverManager for Microsoft Edge
		WebDriverManager.edgedriver().setup();

		// Initialize EdgeDriver
		driver = new EdgeDriver();

		// Navigate to the specified URL
		driver.get("https://talent.capgemini.com/in");

		// Maximize the browser window
		driver.manage().window().maximize();

		// Set implicit wait time for element location to 10 seconds
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@AfterSuite
	public void closeBrowser() {
		// Check if driver is not null before quitting
		if (driver != null) {
			driver.quit();
		}
	}

}
